import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Plus, Search, Layers, Edit2, Trash2,
  Save, X, CheckCircle, XCircle, RefreshCw, Tag,
} from 'lucide-react';

const API_BASE = '/api/categories';

const emptyForm = {
  name:        '',
  code:        '',
  description: '',
  parentId:    '',
  active:      true,
};

const InputField = ({ label, placeholder, value, onChange, icon: Icon, required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={13} /></span>}
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-8' : 'pl-3'} pr-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#ef4444]/30 focus:border-[#ef4444] transition-all`}
      />
    </div>
  </div>
);

export default function ItemCategoriesPage() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [form, setForm]             = useState(emptyForm);
  const [editId, setEditId]         = useState(null);
  const [search, setSearch]         = useState('');
  const [saving, setSaving]         = useState(false);
  const [loading, setLoading]       = useState(false);
  const [toast, setToast]           = useState(null);
  const [useApi, setUseApi]         = useState(false);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => { loadCategories(); }, []);

  const loadCategories = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/getall`);
      if (res.ok) {
        const data = await res.json();
        setCategories(data);
        setUseApi(true);
        setLoading(false);
        return;
      }
    } catch {}
    // Fallback localStorage
    try {
      const d = localStorage.getItem('srivaari_categories');
      if (d) setCategories(JSON.parse(d));
    } catch {}
    setLoading(false);
  };

  const f = (key, val) => setForm(p => ({ ...p, [key]: val }));

  const handleSave = async () => {
    if (!form.name.trim()) { showToast('Category Name is required.', 'error'); return; }
    setSaving(true);

    // Build payload matching backend Category entity
    const payload = {
      name:        form.name.trim(),
      code:        form.code.trim() || null,
      description: form.description.trim() || null,
      active:      form.active,
      parent:      form.parentId ? { id: parseInt(form.parentId) } : null,
    };

    try {
      if (useApi) {
        const url = editId !== null ? `${API_BASE}/${editId}` : `${API_BASE}/create`;
        const method = editId !== null ? 'PUT' : 'POST';
        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          showToast(editId !== null ? 'Category updated.' : 'Category saved.');
          setEditId(null);
          setForm(emptyForm);
          await loadCategories();
          setSaving(false);
          return;
        }
      }
    } catch {}

    // Fallback localStorage
    let stored = [];
    try { const d = localStorage.getItem('srivaari_categories'); if (d) stored = JSON.parse(d); } catch {}
    let updated;
    if (editId !== null) {
      updated = stored.map(c => c.id === editId ? { ...c, ...payload, id: c.id } : c);
      showToast('Category updated.');
      setEditId(null);
    } else {
      updated = [...stored, { ...payload, id: Date.now() }];
      showToast('Category saved.');
    }
    setCategories(updated);
    try { localStorage.setItem('srivaari_categories', JSON.stringify(updated)); } catch {}
    setForm(emptyForm);
    setSaving(false);
  };

  const handleEdit = (cat) => {
    setForm({
      name:        cat.name        || '',
      code:        cat.code        || '',
      description: cat.description || '',
      parentId:    cat.parent?.id  ?? '',
      active:      cat.active      ?? true,
    });
    setEditId(cat.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this category?')) return;
    try {
      if (useApi) {
        const res = await fetch(`${API_BASE}/${id}`, { method: 'DELETE' });
        if (res.ok || res.status === 204) {
          showToast('Category deleted.');
          await loadCategories();
          return;
        }
      }
    } catch {}
    const updated = categories.filter(c => c.id !== id);
    setCategories(updated);
    try { localStorage.setItem('srivaari_categories', JSON.stringify(updated)); } catch {}
    showToast('Category deleted.');
  };

  const filtered = categories.filter(c =>
    !search || (c.name || '').toLowerCase().includes(search.toLowerCase()) ||
    (c.code || '').toLowerCase().includes(search.toLowerCase())
  );

  const parentOptions = categories.filter(c => c.id !== editId);

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-2xl shadow-xl text-sm font-semibold flex items-center gap-2 ${toast.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
          {toast.type === 'error' ? <XCircle size={15} /> : <CheckCircle size={15} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] shadow-sm">
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#ef4444] to-[#f87171] flex items-center justify-center">
            <Layers size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Item Categories</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Manage item classification categories</p>
          </div>
        </div>
        <button onClick={loadCategories} className="ml-auto w-8 h-8 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors" title="Refresh">
          <RefreshCw size={13} className={`text-[#4C708E] ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8]" style={{ borderLeftWidth: 4, borderLeftColor: '#ef4444' }}>
          <div className="w-9 h-9 rounded-xl bg-[#fee2e2] flex items-center justify-center mb-3">
            <Layers size={18} className="text-[#ef4444]" />
          </div>
          <p className="text-3xl font-extrabold text-[#1E3448]">{categories.length}</p>
          <p className="text-xs text-[#8BAFC7] font-medium mt-1 uppercase tracking-wide">Total Categories</p>
        </div>
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8]" style={{ borderLeftWidth: 4, borderLeftColor: '#6366f1' }}>
          <div className="w-9 h-9 rounded-xl bg-[#ede9fe] flex items-center justify-center mb-3">
            <Tag size={18} className="text-[#6366f1]" />
          </div>
          <p className="text-3xl font-extrabold text-[#1E3448]">{categories.filter(c => !c.parent).length}</p>
          <p className="text-xs text-[#8BAFC7] font-medium mt-1 uppercase tracking-wide">Root Categories</p>
        </div>
      </div>

      {/* Form */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] mb-6 overflow-hidden">
        <div className="flex items-center gap-2 px-6 py-4 bg-gradient-to-r from-[#EBF4FB] to-white border-b border-[#D6E6F2]">
          <div className="w-8 h-8 rounded-lg bg-[#ef4444]/10 flex items-center justify-center">
            {editId ? <Edit2 size={15} className="text-[#ef4444]" /> : <Plus size={15} className="text-[#ef4444]" />}
          </div>
          <h2 className="text-sm font-bold text-[#2D4A5E]">{editId ? 'Edit Category' : 'Add New Category'}</h2>
          {editId && (
            <button onClick={() => { setForm(emptyForm); setEditId(null); }} className="ml-auto flex items-center gap-1 text-xs text-[#8BAFC7] hover:text-red-500 transition-colors">
              <X size={13} /> Cancel
            </button>
          )}
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            <InputField label="Category Name" placeholder="e.g. Raw Material" value={form.name} onChange={v => f('name', v)} icon={Layers} required />
            <InputField label="Category Code" placeholder="e.g. CAT001" value={form.code} onChange={v => f('code', v)} icon={Tag} />
            <InputField label="Description" placeholder="Short description…" value={form.description} onChange={v => f('description', v)} />
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Parent Category</label>
              <select
                value={form.parentId}
                onChange={e => f('parentId', e.target.value)}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#ef4444]/30 focus:border-[#ef4444] transition-all appearance-none"
              >
                <option value="">-- No Parent (Root) --</option>
                {parentOptions.map(o => <option key={o.id} value={String(o.id)}>{o.name}</option>)}
              </select>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide mr-2">Status</label>
              <button type="button" onClick={() => f('active', true)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors ${form.active ? 'bg-emerald-500 text-white border-emerald-500' : 'bg-white text-gray-500 border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                Active
              </button>
              <button type="button" onClick={() => f('active', false)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors ${!form.active ? 'bg-[#ef4444] text-white border-[#ef4444]' : 'bg-white text-gray-500 border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                Inactive
              </button>
            </div>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#ef4444] text-white text-sm font-semibold hover:bg-red-600 transition-colors shadow-md disabled:opacity-60"
            >
              {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={15} />}
              {editId ? 'Update Category' : 'Save Category'}
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
        <div className="flex items-center gap-3 px-6 py-4 border-b border-[#E8F1F8]">
          <div className="relative flex-1 max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]" />
            <input
              placeholder="Search categories…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#D6E6F2] text-sm focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30"
            />
          </div>
          <span className="text-xs text-[#8BAFC7] ml-auto">{filtered.length} categories</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-[#ef4444] to-[#f87171] text-white text-xs uppercase tracking-wide">
                {['#', 'Category Name', 'Code', 'Description', 'Parent', 'Status', 'Actions'].map(h => (
                  <th key={h} className="px-5 py-3 text-left font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-14 text-[#8BAFC7] text-sm">No categories found.</td></tr>
              ) : filtered.map((cat, idx) => {
                const parentName = cat.parent?.name || (cat.parentId ? categories.find(c => c.id === cat.parentId)?.name : null) || null;
                return (
                  <tr key={cat.id} className={`border-b border-[#F0F6FB] hover:bg-[#F7FBFE] transition-colors ${idx % 2 === 0 ? '' : 'bg-[#FAFCFE]'}`}>
                    <td className="px-5 py-3.5">
                      <div className="w-7 h-7 rounded-lg bg-[#fee2e2] flex items-center justify-center">
                        <span className="text-xs font-bold text-[#ef4444]">{idx + 1}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-[#EBF4FB] flex items-center justify-center flex-shrink-0">
                          <Layers size={12} className="text-[#4C708E]" />
                        </div>
                        <span className="font-semibold text-[#1E3448] text-xs">{cat.name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs text-[#4C708E] font-mono">{cat.code || '—'}</td>
                    <td className="px-5 py-3.5 text-xs text-gray-500 max-w-[180px] truncate">{cat.description || '—'}</td>
                    <td className="px-5 py-3.5">
                      {parentName
                        ? <span className="px-2.5 py-1 rounded-full bg-[#EBF4FB] text-[#4C708E] text-xs font-semibold">{parentName}</span>
                        : <span className="text-xs text-gray-400">Root</span>}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${cat.active !== false ? 'bg-[#d1fae5] text-[#065f46]' : 'bg-[#f1f5f9] text-[#64748b]'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${cat.active !== false ? 'bg-[#10b981]' : 'bg-[#94a3b8]'}`} />
                        {cat.active !== false ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <button onClick={() => handleEdit(cat)} className="w-7 h-7 rounded-lg bg-[#EBF4FB] hover:bg-[#4C708E] hover:text-white text-[#4C708E] flex items-center justify-center transition-colors"><Edit2 size={12} /></button>
                        <button onClick={() => handleDelete(cat.id)} className="w-7 h-7 rounded-lg bg-[#fee2e2] hover:bg-red-500 hover:text-white text-red-500 flex items-center justify-center transition-colors"><Trash2 size={12} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
