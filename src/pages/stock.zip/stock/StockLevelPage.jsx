import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Plus, Search, Warehouse, Package,
  TrendingUp, AlertCircle, Save, X, Edit2,
  CheckCircle, XCircle, Trash2, Tag, Filter, RefreshCw,
  LayoutGrid, List,
} from 'lucide-react';

const API_LEVELS     = '/api/stock/levels';
const API_ITEMS      = '/api/items';
const API_CATEGORIES = '/api/categories/getall';
const API_WAREHOUSES = '/api/warehouses';

const STOCK_STATUSES = ['BELOW', 'MINIMUM', 'MAXIMUM'];

const emptyForm = {
  itemId:        '',
  categoryId:    '',
  quantity:      '',
  warehouse:     '',
  minStockLevel: '',
  maxStockLevel: '',
  status:        '',
};

/* ─── tiny helpers ─── */
const InputField = ({ label, placeholder, value, onChange, type = 'text', icon: Icon }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">{label}</label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={13} /></span>}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-8' : 'pl-3'} pr-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all`}
      />
    </div>
  </div>
);

const StatCard = ({ label, value, color, icon: Icon }) => (
  <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8]" style={{ borderLeftWidth: 4, borderLeftColor: color }}>
    <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3" style={{ background: `${color}18` }}>
      <Icon size={18} style={{ color }} />
    </div>
    <p className="text-3xl font-extrabold text-[#1E3448]">{value}</p>
    <p className="text-xs text-[#8BAFC7] font-medium mt-1 uppercase tracking-wide">{label}</p>
  </div>
);

const autoStatus = (qty, min, max) => {
  if (!qty || !min) return '';
  if (Number(qty) < Number(min)) return 'BELOW';
  if (max && Number(qty) > Number(max)) return 'MAXIMUM';
  return 'MINIMUM';
};

const StatusBadge = ({ status }) => {
  const map = {
    BELOW:   { bg: '#fee2e2', color: '#dc2626', label: 'Below Min' },
    MINIMUM: { bg: '#d1fae5', color: '#059669', label: 'Normal' },
    MAXIMUM: { bg: '#fef3c7', color: '#d97706', label: 'Overstock' },
  };
  const s = map[status] || { bg: '#f1f5f9', color: '#64748b', label: status || '—' };
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
      style={{ background: s.bg, color: s.color }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: s.color }} />
      {s.label}
    </span>
  );
};

/* ─── tile card ─── */
const StockTile = ({ stock, itemName, categoryName, onEdit, onDelete }) => {
  const statusMap = {
    BELOW:   { bg: '#fee2e2', border: '#fca5a5', text: '#dc2626', label: 'Below Min' },
    MINIMUM: { bg: '#d1fae5', border: '#6ee7b7', text: '#059669', label: 'Normal' },
    MAXIMUM: { bg: '#fef3c7', border: '#fcd34d', text: '#d97706', label: 'Overstock' },
  };
  const s = statusMap[stock.status] || { bg: '#f1f5f9', border: '#e2e8f0', text: '#64748b', label: stock.status || 'Unknown' };
  const pct = stock.maxStockLevel > 0
    ? Math.min(100, Math.round((stock.quantity / stock.maxStockLevel) * 100))
    : 0;

  return (
    <div className="bg-white rounded-2xl shadow-sm border-2 p-5 transition-all hover:shadow-md flex flex-col gap-3"
      style={{ borderColor: s.border }}>
      {/* header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: s.bg }}>
            <Package size={16} style={{ color: s.text }} />
          </div>
          <div className="min-w-0">
            <p className="font-bold text-[#1E3448] text-sm leading-tight truncate">
              {itemName || `Stock #${stock.id}`}
            </p>
            {categoryName && (
              <p className="text-[10px] text-[#8BAFC7] mt-0.5 flex items-center gap-1">
                <Tag size={9} /> {categoryName}
              </p>
            )}
            <p className="text-[10px] text-[#8BAFC7] mt-0.5">
              <Warehouse size={9} className="inline mr-0.5" />{stock.warehouse || '—'}
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ml-2"
          style={{ background: s.bg, color: s.text }}>
          {s.label}
        </span>
      </div>

      {/* qty row */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <p className="text-xl font-extrabold text-[#1E3448]">{stock.quantity ?? '—'}</p>
          <p className="text-[10px] text-[#8BAFC7] uppercase tracking-wide">Current</p>
        </div>
        <div className="border-x border-[#E8F1F8]">
          <p className="text-xl font-extrabold text-[#4C708E]">{stock.minStockLevel ?? '—'}</p>
          <p className="text-[10px] text-[#8BAFC7] uppercase tracking-wide">Min</p>
        </div>
        <div>
          <p className="text-xl font-extrabold text-[#4C708E]">{stock.maxStockLevel ?? '—'}</p>
          <p className="text-[10px] text-[#8BAFC7] uppercase tracking-wide">Max</p>
        </div>
      </div>

      {/* progress bar */}
      {stock.maxStockLevel > 0 && (
        <div>
          <div className="w-full h-1.5 rounded-full bg-[#E8F1F8] overflow-hidden">
            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: s.text }} />
          </div>
          <p className="text-[10px] text-[#8BAFC7] text-right mt-0.5">{pct}% of max</p>
        </div>
      )}

      {/* actions */}
      <div className="flex items-center justify-end gap-2 pt-1 border-t border-[#F0F6FB]">
        <button onClick={() => onEdit(stock)}
          className="w-7 h-7 rounded-lg bg-[#EBF4FB] hover:bg-[#4C708E] hover:text-white text-[#4C708E] flex items-center justify-center transition-colors">
          <Edit2 size={12} />
        </button>
        <button onClick={() => onDelete(stock.id)}
          className="w-7 h-7 rounded-lg bg-[#fee2e2] hover:bg-red-500 hover:text-white text-red-500 flex items-center justify-center transition-colors">
          <Trash2 size={12} />
        </button>
      </div>
    </div>
  );
};

/* ══════════════════════════════════════════ MAIN PAGE ══════════════════════════════════════════ */
export default function StockLevelPage() {
  const navigate = useNavigate();

  const [stocks, setStocks]         = useState([]);
  const [items, setItems]           = useState([]);
  const [categories, setCategories] = useState([]);
  const [warehouses, setWarehouses] = useState([]);

  const [form, setForm]     = useState(emptyForm);
  const [editId, setEditId] = useState(null);

  const [search, setSearch]       = useState('');
  const [filterWH, setFilterWH]   = useState('ALL');
  const [filterItem, setFilterItem]     = useState('ALL');
  const [filterCat, setFilterCat]       = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');

  const [saving, setSaving]   = useState(false);
  const [loading, setLoading] = useState(false);
  const [toast, setToast]     = useState(null);
  const [useApi, setUseApi]   = useState(false);
  const [viewMode, setViewMode] = useState('tile'); // 'tile' | 'table'

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => { loadAll(); }, []);

  /* ── loaders ── */
  const loadAll = async () => {
    setLoading(true);
    await Promise.all([loadStocks(), loadItems(), loadCategories(), loadWarehouses()]);
    setLoading(false);
  };

  const loadStocks = async () => {
    try {
      const res = await fetch(API_LEVELS);
      if (res.ok) { setStocks(await res.json()); setUseApi(true); return; }
    } catch {}
    try { const d = localStorage.getItem('srivaari_stock_levels'); if (d) setStocks(JSON.parse(d)); } catch {}
  };

  const loadItems = async () => {
    try {
      const res = await fetch(API_ITEMS);
      if (res.ok) { setItems(await res.json()); return; }
    } catch {}
    try { const d = localStorage.getItem('srivaari_itemslist'); if (d) setItems(JSON.parse(d)); } catch {}
  };

  const loadCategories = async () => {
    try {
      const res = await fetch(API_CATEGORIES);
      if (res.ok) { setCategories(await res.json()); return; }
    } catch {}
    try { const d = localStorage.getItem('srivaari_categories'); if (d) setCategories(JSON.parse(d)); } catch {}
  };

  const loadWarehouses = async () => {
    try {
      const res = await fetch(API_WAREHOUSES);
      if (res.ok) { setWarehouses(await res.json()); return; }
    } catch {}
    try { const d = localStorage.getItem('srivaari_warehouselist'); if (d) setWarehouses(JSON.parse(d)); } catch {}
  };

  /* ── helpers ── */
  const getItemById = (id) => items.find(i => String(i.id) === String(id));

  const getItemName = (stock) => {
    const item = getItemById(stock.itemId);
    return item ? (item.name || item.itemName) : (stock.itemName || null);
  };

  const getCategoryNameForItem = (stock) => {
    const item = getItemById(stock.itemId);
    const catId = item?.category?.id || item?.categoryId;
    if (!catId) return null;
    const cat = categories.find(c => String(c.id) === String(catId));
    return cat?.name || null;
  };

  const warehouseOptions = warehouses.length > 0
    ? warehouses.map(w => w.name || w.warehouseName || w.code || w.warehouseCode).filter(Boolean)
    : ['WAREHOUSEA', 'WAREHOUSEB', 'WAREHOUSEC'];

  const ff = (k, v) => {
    setForm(p => {
      const next = { ...p, [k]: v };
      // When category changes, reset item selection
      if (k === 'categoryId') next.itemId = '';
      // Auto-calculate status
      if (['quantity', 'minStockLevel', 'maxStockLevel'].includes(k)) {
        next.status = autoStatus(
          k === 'quantity' ? v : next.quantity,
          k === 'minStockLevel' ? v : next.minStockLevel,
          k === 'maxStockLevel' ? v : next.maxStockLevel,
        );
      }
      return next;
    });
  };

  /* Items filtered by selected category in form */
  const formItemOptions = form.categoryId
    ? items.filter(i => String(i.category?.id || i.categoryId || '') === String(form.categoryId))
    : items;

  /* ── save ── */
  const handleSave = async () => {
    if (!form.warehouse) { showToast('Warehouse is required.', 'error'); return; }
    setSaving(true);

    const selectedItem = getItemById(form.itemId);
    const payload = {
      quantity:      form.quantity !== '' ? parseFloat(form.quantity) : null,
      warehouse:     form.warehouse,
      minStockLevel: form.minStockLevel !== '' ? parseFloat(form.minStockLevel) : null,
      maxStockLevel: form.maxStockLevel !== '' ? parseFloat(form.maxStockLevel) : null,
      status:        form.status || autoStatus(form.quantity, form.minStockLevel, form.maxStockLevel) || null,
    };

    try {
      if (useApi) {
        const url = editId !== null ? `${API_LEVELS}/${editId}` : API_LEVELS;
        const method = editId !== null ? 'PUT' : 'POST';
        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          showToast(editId !== null ? 'Stock level updated.' : 'Stock level added.');
          setEditId(null); setForm(emptyForm);
          await loadStocks();
          setSaving(false); return;
        }
      }
    } catch {}

    // Fallback localStorage
    let stored = [];
    try { const d = localStorage.getItem('srivaari_stock_levels'); if (d) stored = JSON.parse(d); } catch {}
    const lsPayload = {
      ...payload,
      itemId:    form.itemId || null,
      itemName:  selectedItem ? (selectedItem.name || selectedItem.itemName) : null,
    };
    let updated;
    if (editId !== null) {
      updated = stored.map(s => s.id === editId ? { ...s, ...lsPayload } : s);
      showToast('Stock level updated.'); setEditId(null);
    } else {
      updated = [...stored, { ...lsPayload, id: Date.now() }];
      showToast('Stock level added.');
    }
    setStocks(updated);
    try { localStorage.setItem('srivaari_stock_levels', JSON.stringify(updated)); } catch {}
    setForm(emptyForm);
    setSaving(false);
  };

  const handleEdit = (s) => {
    setForm({
      itemId:        s.itemId        ?? '',
      categoryId:    getItemById(s.itemId)?.category?.id ?? getItemById(s.itemId)?.categoryId ?? '',
      quantity:      s.quantity      ?? '',
      warehouse:     s.warehouse     ?? '',
      minStockLevel: s.minStockLevel ?? '',
      maxStockLevel: s.maxStockLevel ?? '',
      status:        s.status        ?? '',
    });
    setEditId(s.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this stock entry?')) return;
    const updated = stocks.filter(s => s.id !== id);
    setStocks(updated);
    try { localStorage.setItem('srivaari_stock_levels', JSON.stringify(updated)); } catch {}
    showToast('Entry deleted.');
  };

  /* ── filtering ── */
  const filtered = stocks.filter(s => {
    const item     = getItemById(s.itemId);
    const catId    = item?.category?.id || item?.categoryId;
    const itemName = item ? (item.name || item.itemName) : (s.itemName || '');

    const matchQ    = !search || itemName.toLowerCase().includes(search.toLowerCase()) || (s.warehouse || '').toLowerCase().includes(search.toLowerCase());
    const matchWH   = filterWH === 'ALL' || s.warehouse === filterWH;
    const matchItem = filterItem === 'ALL' || String(s.itemId || '') === filterItem;
    const matchCat  = filterCat === 'ALL' || String(catId || '') === filterCat;
    const matchStat = filterStatus === 'ALL' || s.status === filterStatus;
    return matchQ && matchWH && matchItem && matchCat && matchStat;
  });

  const total  = stocks.length;
  const below  = stocks.filter(s => s.status === 'BELOW').length;
  const over   = stocks.filter(s => s.status === 'MAXIMUM').length;
  const normal = stocks.filter(s => s.status === 'MINIMUM').length;

  /* ══════════════════════════════ RENDER ══════════════════════════════ */
  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>

      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-2xl shadow-xl text-sm font-semibold flex items-center gap-2 ${toast.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
          {toast.type === 'error' ? <XCircle size={15} /> : <CheckCircle size={15} />} {toast.msg}
        </div>
      )}

      {/* ── Header ── */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4C708E] to-[#8BAFC7] flex items-center justify-center">
            <Warehouse size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Stock Levels</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Monitor stock quantities across warehouses</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {/* View toggle */}
          <button onClick={() => setViewMode('tile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${viewMode === 'tile' ? 'bg-[#4C708E] text-white' : 'bg-white text-[#4C708E] border border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
            <LayoutGrid size={13} /> Tiles
          </button>
          <button onClick={() => setViewMode('table')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${viewMode === 'table' ? 'bg-[#4C708E] text-white' : 'bg-white text-[#4C708E] border border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
            <List size={13} /> Table
          </button>
          <button onClick={loadAll}
            className="w-8 h-8 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors" title="Refresh">
            <RefreshCw size={13} className={`text-[#4C708E] ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Entries" value={total}  color="#4C708E" icon={Warehouse} />
        <StatCard label="Normal"        value={normal} color="#059669" icon={TrendingUp} />
        <StatCard label="Below Min"     value={below}  color="#dc2626" icon={AlertCircle} />
        <StatCard label="Overstock"     value={over}   color="#d97706" icon={CheckCircle} />
      </div>

      {/* ── Add / Edit Form ── */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] mb-6 overflow-hidden">
        <div className="flex items-center gap-2 px-6 py-4 bg-gradient-to-r from-[#EBF4FB] to-white border-b border-[#D6E6F2]">
          <Plus size={15} className="text-[#4C708E]" />
          <h2 className="text-sm font-bold text-[#2D4A5E]">
            {editId !== null ? 'Update Stock Level' : 'Add Stock Level'}
          </h2>
          {editId !== null && (
            <button onClick={() => { setForm(emptyForm); setEditId(null); }}
              className="ml-auto flex items-center gap-1 text-xs text-[#8BAFC7] hover:text-red-500">
              <X size={13} /> Cancel
            </button>
          )}
        </div>
        <div className="p-6">

          {/* Row 1: Item Category, Item List, Warehouse */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">

            {/* Item Category dropdown */}
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide flex items-center gap-1">
                <Tag size={11} /> Item Category
              </label>
              <select
                value={form.categoryId}
                onChange={e => ff('categoryId', e.target.value)}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all appearance-none"
              >
                <option value="">All Categories</option>
                {categories.map(c => (
                  <option key={c.id} value={String(c.id)}>{c.name}</option>
                ))}
              </select>
            </div>

            {/* Item List dropdown (filtered by selected category) */}
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide flex items-center gap-1">
                <Package size={11} /> Item List
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]">
                  <Package size={13} />
                </span>
                <select
                  value={form.itemId}
                  onChange={e => ff('itemId', e.target.value)}
                  className="w-full rounded-xl border border-[#D6E6F2] bg-white pl-8 pr-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all appearance-none"
                >
                  <option value="">Select Item…</option>
                  {formItemOptions.map(i => (
                    <option key={i.id} value={String(i.id)}>{i.name || i.itemName}</option>
                  ))}
                </select>
              </div>
              {form.categoryId && formItemOptions.length === 0 && (
                <p className="text-[10px] text-amber-500 mt-0.5">No items in this category</p>
              )}
            </div>

            {/* Warehouse */}
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide flex items-center gap-1">
                <Warehouse size={11} /> Warehouse <span className="text-red-400">*</span>
              </label>
              <select
                value={form.warehouse}
                onChange={e => ff('warehouse', e.target.value)}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all appearance-none"
              >
                <option value="">Select Warehouse…</option>
                {warehouseOptions.map(w => <option key={w} value={w}>{w}</option>)}
              </select>
            </div>
          </div>

          {/* Row 2: Qty, Min, Max, Status */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <InputField label="Quantity"        placeholder="Current Quantity"  value={form.quantity}      onChange={v => ff('quantity', v)}      type="number" />
            <InputField label="Min Stock Level" placeholder="Minimum Level"     value={form.minStockLevel} onChange={v => ff('minStockLevel', v)} type="number" />
            <InputField label="Max Stock Level" placeholder="Maximum Level"     value={form.maxStockLevel} onChange={v => ff('maxStockLevel', v)} type="number" />
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Status</label>
              <select
                value={form.status}
                onChange={e => ff('status', e.target.value)}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all appearance-none"
              >
                <option value="">Auto (calculated)</option>
                {STOCK_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          {/* Auto status preview */}
          {form.quantity && form.minStockLevel && (
            <div className="mb-4 px-4 py-2 rounded-xl bg-[#EBF4FB] text-xs text-[#4C708E] font-semibold inline-flex items-center gap-2">
              <CheckCircle size={12} />
              Auto Status: <span className="font-bold">{autoStatus(form.quantity, form.minStockLevel, form.maxStockLevel) || '—'}</span>
            </div>
          )}

          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#4C708E] text-white text-sm font-semibold hover:bg-[#2D4A5E] transition-colors shadow-md disabled:opacity-60"
            >
              {saving
                ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                : <Save size={15} />}
              {editId !== null ? 'Update' : 'Save'}
            </button>
          </div>
        </div>
      </div>

      {/* ── Filter Bar ── */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] px-6 py-4 mb-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]" />
            <input
              placeholder="Search by item or warehouse…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#D6E6F2] text-sm focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30"
            />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Filter size={13} className="text-[#8BAFC7]" />
            {/* Item List filter */}
            <select value={filterItem} onChange={e => setFilterItem(e.target.value)}
              className="rounded-xl border border-[#D6E6F2] px-3 py-2 text-xs text-[#4C708E] focus:outline-none bg-white">
              <option value="ALL">All Items</option>
              {items.map(i => <option key={i.id} value={String(i.id)}>{i.name || i.itemName}</option>)}
            </select>
            {/* Category filter */}
            <select value={filterCat} onChange={e => setFilterCat(e.target.value)}
              className="rounded-xl border border-[#D6E6F2] px-3 py-2 text-xs text-[#4C708E] focus:outline-none bg-white">
              <option value="ALL">All Categories</option>
              {categories.map(c => <option key={c.id} value={String(c.id)}>{c.name}</option>)}
            </select>
            {/* Warehouse filter */}
            <select value={filterWH} onChange={e => setFilterWH(e.target.value)}
              className="rounded-xl border border-[#D6E6F2] px-3 py-2 text-xs text-[#4C708E] focus:outline-none bg-white">
              <option value="ALL">All Warehouses</option>
              {warehouseOptions.map(w => <option key={w} value={w}>{w}</option>)}
            </select>
            {/* Status filter */}
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
              className="rounded-xl border border-[#D6E6F2] px-3 py-2 text-xs text-[#4C708E] focus:outline-none bg-white">
              <option value="ALL">All Statuses</option>
              <option value="BELOW">Below Min</option>
              <option value="MINIMUM">Normal</option>
              <option value="MAXIMUM">Overstock</option>
            </select>
          </div>
          <span className="text-xs text-[#8BAFC7] ml-auto">{filtered.length} entries</span>
        </div>
      </div>

      {/* ── TILE VIEW ── */}
      {viewMode === 'tile' ? (
        <>
          {/* Category quick-filter chips */}
          {categories.length > 0 && (
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              <span className="text-xs font-semibold text-[#4C708E]">Category:</span>
              <button
                onClick={() => setFilterCat('ALL')}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors border ${filterCat === 'ALL' ? 'bg-[#4C708E] text-white border-[#4C708E]' : 'bg-white text-[#4C708E] border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                All
              </button>
              {categories.map(c => (
                <button key={c.id}
                  onClick={() => setFilterCat(String(c.id))}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors border ${filterCat === String(c.id) ? 'bg-[#4C708E] text-white border-[#4C708E]' : 'bg-white text-[#4C708E] border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                  {c.name}
                </button>
              ))}
            </div>
          )}

          {/* Item quick-filter chips */}
          {items.length > 0 && (
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              <span className="text-xs font-semibold text-[#4C708E]">Item:</span>
              <button
                onClick={() => setFilterItem('ALL')}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors border ${filterItem === 'ALL' ? 'bg-[#ef4444] text-white border-[#ef4444]' : 'bg-white text-[#4C708E] border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                All
              </button>
              {(filterCat === 'ALL' ? items : items.filter(i => String(i.category?.id || i.categoryId || '') === filterCat))
                .slice(0, 12)
                .map(i => (
                  <button key={i.id}
                    onClick={() => setFilterItem(String(i.id))}
                    className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors border ${filterItem === String(i.id) ? 'bg-[#ef4444] text-white border-[#ef4444]' : 'bg-white text-[#4C708E] border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                    {i.name || i.itemName}
                  </button>
                ))}
            </div>
          )}

          {/* Tiles grid */}
          {filtered.length === 0 ? (
            <div className="bg-white rounded-2xl p-14 text-center text-[#8BAFC7] text-sm shadow-sm border border-[#E8F1F8]">
              {loading ? 'Loading stock levels…' : 'No stock entries found. Add one above.'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filtered.map(s => (
                <StockTile
                  key={s.id}
                  stock={s}
                  itemName={getItemName(s)}
                  categoryName={getCategoryNameForItem(s)}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          )}
        </>
      ) : (
        /* ── TABLE VIEW ── */
        <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-[#4C708E] to-[#6B92AB] text-white text-xs uppercase tracking-wide">
                  {['Item', 'Category', 'Warehouse', 'Quantity', 'Min Level', 'Max Level', 'Status', 'Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left font-semibold whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-14 text-[#8BAFC7] text-sm">
                      {loading ? 'Loading…' : 'No stock entries found.'}
                    </td>
                  </tr>
                ) : filtered.map((s, idx) => (
                  <tr key={s.id}
                    className={`border-b border-[#F0F6FB] hover:bg-[#F7FBFE] transition-colors ${idx % 2 === 0 ? '' : 'bg-[#FAFCFE]'}`}>
                    <td className="px-4 py-3 text-xs font-semibold text-[#1E3448]">
                      {getItemName(s) || <span className="text-[#8BAFC7]">—</span>}
                    </td>
                    <td className="px-4 py-3 text-xs text-[#4C708E]">
                      {getCategoryNameForItem(s) || <span className="text-[#8BAFC7]">—</span>}
                    </td>
                    <td className="px-4 py-3 text-xs text-[#4C708E]">{s.warehouse}</td>
                    <td className="px-4 py-3 text-xs font-bold text-[#1E3448]">{s.quantity ?? '—'}</td>
                    <td className="px-4 py-3 text-xs text-[#6B7280]">{s.minStockLevel ?? '—'}</td>
                    <td className="px-4 py-3 text-xs text-[#6B7280]">{s.maxStockLevel ?? '—'}</td>
                    <td className="px-4 py-3"><StatusBadge status={s.status} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button onClick={() => handleEdit(s)}
                          className="w-7 h-7 rounded-lg bg-[#EBF4FB] hover:bg-[#4C708E] hover:text-white text-[#4C708E] flex items-center justify-center transition-colors">
                          <Edit2 size={12} />
                        </button>
                        <button onClick={() => handleDelete(s.id)}
                          className="w-7 h-7 rounded-lg bg-[#fee2e2] hover:bg-red-500 hover:text-white text-red-500 flex items-center justify-center transition-colors">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}