import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Plus, Search, Package, Tag,
  DollarSign, Edit2, Trash2, Save, X,
  CheckCircle, XCircle, AlertCircle, Filter,
} from 'lucide-react';

const LS_KEY        = 'srivaari_items';
const LS_CATEGORIES = 'srivaari_categories';
const UNITS         = ['KG', 'LITER', 'NOS', 'BOX', 'PACK'];

const emptyForm = {
  itemCode:    '',
  itemName:    '',
  description: '',
  category:    '',
  unit:        '',
  price:       '',
  active:      true,
};

const InputField = ({ label, placeholder, value, onChange, type = 'text', icon: Icon }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">{label}</label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={13} /></span>}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-8' : 'pl-3'} pr-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all`}
      />
    </div>
  </div>
);

const SelectField = ({ label, value, onChange, options }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">{label}</label>
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all appearance-none"
    >
      <option value="">Select…</option>
      {options.map(o => <option key={o} value={o}>{o}</option>)}
    </select>
  </div>
);

const StatusBadge = ({ active }) => (
  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
    style={active ? { background: '#d1fae5', color: '#065f46' } : { background: '#f1f5f9', color: '#64748b' }}>
    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: active ? '#10b981' : '#94a3b8' }} />
    {active ? 'Active' : 'Inactive'}
  </span>
);

const StatCard = ({ label, value, color, icon: Icon }) => (
  <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8]" style={{ borderLeftWidth: 4, borderLeftColor: color }}>
    <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3" style={{ background: `${color}18` }}>
      <Icon size={18} style={{ color }} />
    </div>
    <p className="text-3xl font-extrabold text-[#1E3448]">{value}</p>
    <p className="text-xs text-[#8BAFC7] font-medium mt-1 uppercase tracking-wide">{label}</p>
  </div>
);

export default function ItemCatalogPage() {
  const navigate = useNavigate();
  const [items, setItems]         = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm]           = useState(emptyForm);
  const [editId, setEditId]       = useState(null);
  const [search, setSearch]       = useState('');
  const [filterCat, setFilterCat] = useState('ALL');
  const [filterActive, setFilterActive] = useState('ALL');
  const [saving, setSaving]       = useState(false);
  const [toast, setToast]         = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => {
    try { const d = localStorage.getItem(LS_KEY);        if (d) setItems(JSON.parse(d));      } catch {}
    try { const c = localStorage.getItem(LS_CATEGORIES); if (c) setCategories(JSON.parse(c)); } catch {}
  }, []);

  const saveToStorage = (data) => {
    try { localStorage.setItem(LS_KEY, JSON.stringify(data)); } catch {}
  };

  const f = (key, val) => setForm(p => ({ ...p, [key]: val }));

  const handleSave = () => {
    if (!form.itemCode || !form.itemName) {
      showToast('Item Code and Item Name are required.', 'error');
      return;
    }
    setSaving(true);
    const payload = {
      sku:         form.itemCode,   // backend field: sku
      name:        form.itemName,   // backend field: name
      description: form.description || null,
      category:    form.category ? { name: form.category } : null,
      unit:        form.unit || null,
      price:       form.price !== '' ? parseFloat(form.price) : null,
      active:      form.active,
      // Keep legacy fields for localStorage compatibility
      itemCode:    form.itemCode,
      itemName:    form.itemName,
    };
    let updated;
    if (editId !== null) {
      updated = items.map(it => it.id === editId ? { ...it, ...payload } : it);
      showToast('Item updated.');
      setEditId(null);
    } else {
      updated = [...items, { ...payload, id: Date.now() }];
      showToast('Item saved.');
    }
    setItems(updated);
    saveToStorage(updated);
    setForm(emptyForm);
    setSaving(false);
  };

  const handleEdit = (item) => {
    setForm({
      itemCode:    item.itemCode    || '',
      itemName:    item.itemName    || '',
      description: item.description || '',
      category:    item.category    || '',
      unit:        item.unit        || '',
      price:       item.price       ?? '',
      active:      item.active      ?? true,
    });
    setEditId(item.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id) => {
    const updated = items.filter(it => it.id !== id);
    setItems(updated);
    saveToStorage(updated);
    showToast('Item deleted.');
  };

  const filtered = items.filter(i => {
    const q = search.toLowerCase();
    const matchQ = !q || (i.itemName||'').toLowerCase().includes(q) || (i.itemCode||'').toLowerCase().includes(q);
    const matchC = filterCat === 'ALL' || i.category === filterCat;
    const matchA = filterActive === 'ALL' || (filterActive === 'Active' ? i.active : !i.active);
    return matchQ && matchC && matchA;
  });

  const stats = [
    { label: 'Total Items', value: items.length,                        color: '#4C708E', icon: Package },
    { label: 'Active',      value: items.filter(i => i.active).length,  color: '#059669', icon: CheckCircle },
    { label: 'Inactive',    value: items.filter(i => !i.active).length, color: '#d97706', icon: AlertCircle },
    { label: 'Categories',  value: [...new Set(items.map(i => i.category).filter(Boolean))].length, color: '#6366f1', icon: Tag },
  ];

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-2xl shadow-xl text-sm font-semibold flex items-center gap-2 ${toast.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
          {toast.type === 'error' ? <XCircle size={15} /> : <CheckCircle size={15} />}
          {toast.msg}
        </div>
      )}

      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4C708E] to-[#8BAFC7] flex items-center justify-center">
            <Package size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Item Catalog</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Manage inventory items, codes and pricing</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] mb-6 overflow-hidden">
        <div className="flex items-center gap-2 px-6 py-4 bg-gradient-to-r from-[#EBF4FB] to-white border-b border-[#D6E6F2]">
          <div className="w-8 h-8 rounded-lg bg-[#4C708E]/10 flex items-center justify-center">
            {editId ? <Edit2 size={15} className="text-[#4C708E]" /> : <Plus size={15} className="text-[#4C708E]" />}
          </div>
          <h2 className="text-sm font-bold text-[#2D4A5E]">{editId ? 'Update Item' : 'Add New Item'}</h2>
          {editId && (
            <button onClick={() => { setForm(emptyForm); setEditId(null); }} className="ml-auto flex items-center gap-1 text-xs text-[#8BAFC7] hover:text-red-500 transition-colors">
              <X size={13} /> Cancel
            </button>
          )}
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <InputField label="Item Code"  placeholder="e.g. ITM-001" value={form.itemCode}  onChange={v => f('itemCode', v)}  icon={Tag} />
            <InputField label="Item Name"  placeholder="Item Name"     value={form.itemName}  onChange={v => f('itemName', v)}  icon={Package} />
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Category</label>
              <select value={form.category} onChange={e => f('category', e.target.value)}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all appearance-none">
                <option value="">Select Category…</option>
                {categories.length > 0
                  ? categories.map(c => <option key={c.id} value={c.categoryName}>{c.categoryName}</option>)
                  : ['Raw Material','Finished Good','Spare Parts','Consumable','Packaging','Equipment','Electronics'].map(c => <option key={c} value={c}>{c}</option>)
                }
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <SelectField label="Unit"       value={form.unit}  onChange={v => f('unit', v)}   options={UNITS} />
            <InputField  label="Price (₹)"  placeholder="Price" value={form.price} onChange={v => f('price', v)} type="number" icon={DollarSign} />
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Status</label>
              <div className="flex items-center gap-3 mt-1">
                <button type="button" onClick={() => f('active', true)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors ${form.active ? 'bg-emerald-500 text-white border-emerald-500' : 'bg-white text-gray-500 border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                  Active
                </button>
                <button type="button" onClick={() => f('active', false)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors ${!form.active ? 'bg-[#4C708E] text-white border-[#4C708E]' : 'bg-white text-gray-500 border-[#D6E6F2] hover:bg-[#EBF4FB]'}`}>
                  Inactive
                </button>
              </div>
            </div>
          </div>
          <div className="mb-5">
            <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide block mb-1">Description</label>
            <textarea
              placeholder="Item description…"
              value={form.description}
              onChange={e => f('description', e.target.value)}
              rows={2}
              className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all resize-none"
            />
          </div>
          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#4C708E] text-white text-sm font-semibold hover:bg-[#2D4A5E] transition-colors shadow-md disabled:opacity-60"
            >
              {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={15} />}
              {editId ? 'Update Item' : 'Save Item'}
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 px-6 py-4 border-b border-[#E8F1F8]">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]" />
            <input
              placeholder="Search by name or item code…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#D6E6F2] text-sm focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={13} className="text-[#8BAFC7]" />
            <select value={filterCat} onChange={e => setFilterCat(e.target.value)} className="rounded-xl border border-[#D6E6F2] px-3 py-2 text-xs text-[#4C708E] focus:outline-none">
              <option value="ALL">All Categories</option>
              {(categories.length > 0 ? categories.map(c => c.categoryName) : ['Raw Material','Finished Good','Spare Parts','Consumable','Packaging','Equipment','Electronics']).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={filterActive} onChange={e => setFilterActive(e.target.value)} className="rounded-xl border border-[#D6E6F2] px-3 py-2 text-xs text-[#4C708E] focus:outline-none">
              <option value="ALL">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <span className="text-xs text-[#8BAFC7] ml-auto">{filtered.length} items</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-[#4C708E] to-[#6B92AB] text-white text-xs uppercase tracking-wide">
                {['Item', 'Code', 'Category', 'Unit', 'Price (₹)', 'Status', 'Actions'].map(h => (
                  <th key={h} className="px-5 py-3 text-left font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-14 text-[#8BAFC7] text-sm">No items found.</td></tr>
              ) : filtered.map((item, idx) => (
                <tr key={item.id} className={`border-b border-[#F0F6FB] hover:bg-[#F7FBFE] transition-colors ${idx % 2 === 0 ? '' : 'bg-[#FAFCFE]'}`}>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#EBF4FB] to-[#D6E6F2] flex items-center justify-center flex-shrink-0">
                        <Package size={13} className="text-[#4C708E]" />
                      </div>
                      <p className="font-semibold text-[#1E3448] text-xs">{item.itemName}</p>
                    </div>
                  </td>
                  <td className="px-5 py-3.5 text-xs text-[#4C708E] font-mono">{item.itemCode}</td>
                  <td className="px-5 py-3.5 text-xs text-[#4C708E] font-medium">{item.category || '—'}</td>
                  <td className="px-5 py-3.5 text-center">
                    <span className="px-2.5 py-1 rounded-full bg-[#EBF4FB] text-[#4C708E] text-xs font-semibold">{item.unit || '—'}</span>
                  </td>
                  <td className="px-5 py-3.5 font-bold text-[#2D4A5E] text-xs">₹{Number(item.price || 0).toLocaleString('en-IN')}</td>
                  <td className="px-5 py-3.5"><StatusBadge active={item.active} /></td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2">
                      <button onClick={() => handleEdit(item)} className="w-7 h-7 rounded-lg bg-[#EBF4FB] hover:bg-[#4C708E] hover:text-white text-[#4C708E] flex items-center justify-center transition-colors"><Edit2 size={12} /></button>
                      <button onClick={() => handleDelete(item.id)} className="w-7 h-7 rounded-lg bg-[#fee2e2] hover:bg-red-500 hover:text-white text-red-500 flex items-center justify-center transition-colors"><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
