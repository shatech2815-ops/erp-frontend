import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, BarChart2, FileText, ArrowLeftRight, Zap } from 'lucide-react';

const REPORT_SECTIONS = [
  {
    label: 'Stock Report',
    desc:  'Opening stock, stock in/out and closing stock per item',
    icon:  BarChart2,
    route: '/dashboard/stock/reports/stock-report',
    color: '#dc2626',
    bg:    '#fee2e2',
  },
  {
    label: 'Inventory Report',
    desc:  'Available, reserved and damaged inventory with valuation',
    icon:  FileText,
    route: '/dashboard/stock/reports/inventory-report',
    color: '#059669',
    bg:    '#d1fae5',
  },
  {
    label: 'Stock Movement Report',
    desc:  'Track all IN, OUT and TRANSFER stock movements',
    icon:  ArrowLeftRight,
    route: '/dashboard/stock/reports/stock-movement-report',
    color: '#4C708E',
    bg:    '#EBF4FB',
  },
  {
    label: 'Production Report',
    desc:  'Production batches, efficiency and status analytics',
    icon:  Zap,
    route: '/dashboard/stock/reports/production-report',
    color: '#d97706',
    bg:    '#fef3c7',
  },
];

export default function StockReportsPage() {
  const navigate = useNavigate();

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm"
        >
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#dc2626] to-[#f87171] flex items-center justify-center">
            <BarChart2 size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Reports</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Stock and inventory analytics</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {REPORT_SECTIONS.map((sec, idx) => {
          const Icon = sec.icon;
          return (
            <button
              key={idx}
              onClick={() => navigate(sec.route)}
              className="relative flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8] hover:shadow-xl hover:-translate-y-1 transition-all duration-200 group text-left overflow-hidden"
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all duration-200 group-hover:scale-110"
                style={{ background: sec.bg }}
              >
                <Icon size={24} style={{ color: sec.color }} />
              </div>
              <div className="flex-1">
                <p className="font-bold text-[#1E3448] text-base group-hover:text-[#4C708E] transition-colors">{sec.label}</p>
                <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{sec.desc}</p>
              </div>
              <span className="text-2xl font-black opacity-10 absolute right-4 top-1/2 -translate-y-1/2" style={{ color: sec.color }}>
                {idx + 1}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
