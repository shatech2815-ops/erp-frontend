import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Plus, Search, Package, Calendar, Hash,
  Edit2, Trash2, Save, AlertCircle, CheckCircle,
  RefreshCw, ChevronRight, Filter, X,
} from 'lucide-react';

const LS_KEY    = 'srivaari_workorders';
const LS_ITEMS  = 'srivaari_itemslist';
const LS_PLANS  = 'srivaari_productionplans';

const WORK_ORDER_STATUSES = ['CREATED', 'RELEASED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'];

const STATUS_COLORS = {
  CREATED:     { bg: '#f1f5f9', color: '#64748b' },
  RELEASED:    { bg: '#dbeafe', color: '#1d4ed8' },
  IN_PROGRESS: { bg: '#fef3c7', color: '#d97706' },
  COMPLETED:   { bg: '#d1fae5', color: '#059669' },
};

const StatusBadge = ({ status }) => {
  const c = STATUS_COLORS[status] || STATUS_COLORS.CREATED;
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold"
      style={{ background: c.bg, color: c.color }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: c.color }} />
      {status?.replace('_', ' ')}
    </span>
  );
};

const StatCard = ({ label, value, color, icon: Icon }) => (
  <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8F1F8]"
    style={{ borderLeftWidth: 4, borderLeftColor: color }}>
    <div className="w-8 h-8 rounded-xl flex items-center justify-center mb-2" style={{ background: `${color}18` }}>
      <Icon size={16} style={{ color }} />
    </div>
    <p className="text-2xl font-extrabold text-[#1E3448]">{value}</p>
    <p className="text-xs text-[#8BAFC7] font-medium mt-0.5 uppercase tracking-wide">{label}</p>
  </div>
);

const emptyForm = {
  workOrderCode: '', quantity: '', productId: '', productionPlanId: '',
  startDate: '', endDate: '', status: 'CREATED',
};

const InputField = ({ label, placeholder, value, onChange, type = 'text', icon: Icon, required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={14} /></span>}
      <input type={type} placeholder={placeholder} value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-9' : 'pl-4'} pr-4 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all`}
      />
    </div>
  </div>
);

export default function WorkOrdersPage() {
  const navigate = useNavigate();
  const [workOrders, setWorkOrders] = useState([]);
  const [products, setProducts]     = useState([]);
  const [plans, setPlans]           = useState([]);
  const [search, setSearch]         = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showForm, setShowForm]     = useState(false);
  const [form, setForm]             = useState(emptyForm);
  const [editId, setEditId]         = useState(null);
  const [saving, setSaving]         = useState(false);
  const [loading, setLoading]       = useState(false);
  const [toast, setToast]           = useState(null);
  const [deleteId, setDeleteId]     = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const set = (field, val) => setForm(f => ({ ...f, [field]: val }));

  const loadFromStorage = () => {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch { return []; }
  };

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [wRes, pRes, plRes] = await Promise.all([

      ]);
      if (wRes.ok) { const d = await wRes.json(); setWorkOrders(d); localStorage.setItem(LS_KEY, JSON.stringify(d)); }
      else setWorkOrders(loadFromStorage());
      if (pRes.ok) setProducts(await pRes.json());
      if (plRes.ok) setPlans(await plRes.json());
    } catch {
      setWorkOrders(loadFromStorage());
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleSave = () => {
    if (!form.workOrderCode || !form.productId) { showToast('Work Order Code and Product are required.', 'error'); return; }
    setSaving(true);
    const payload = {
      workOrderCode:    form.workOrderCode,
      quantity:         parseInt(form.quantity) || 0,
      productId:        form.productId,
      productionPlanId: form.productionPlanId,
      startDate:        form.startDate,
      endDate:          form.endDate,
      status:           form.status || 'CREATED',
    };
    let stored = [];
    try { const d = localStorage.getItem(LS_KEY); if (d) stored = JSON.parse(d); } catch {}
    let updated;
    if (editId !== null) {
      updated = stored.map(w => w.id === editId ? { ...w, ...payload } : w);
      showToast('Work order updated.');
      setEditId(null);
    } else {
      updated = [...stored, { ...payload, id: Date.now() }];
      showToast('Work order created.');
    }
    setWorkOrders(updated);
    try { localStorage.setItem(LS_KEY, JSON.stringify(updated)); } catch {}
    setForm(emptyForm);
    setSaving(false);
  };

  const handleEdit = (wo) => {
    setForm({
      workOrderCode:    wo.workOrderCode    || '',
      quantity:         wo.quantity         ?? '',
      productId:        wo.product?.id      ?? wo.productId ?? '',
      productionPlanId: wo.productionPlanning?.id ?? wo.productionPlanId ?? '',
      startDate:        wo.startDate        || '',
      endDate:          wo.endDate          || '',
      status:           wo.status           || 'CREATED',
    });
    setEditId(wo.id);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    let stored = [];
    try { const d = localStorage.getItem(LS_KEY); if (d) stored = JSON.parse(d); } catch {}
    const updated = stored.filter(w => w.id !== id);
    setWorkOrders(updated);
    try { localStorage.setItem(LS_KEY, JSON.stringify(updated)); } catch {}
    showToast('Work order deleted.');
  };

  const filtered = workOrders.filter(wo => {
    const q = search.toLowerCase();
    const matchSearch = !q || wo.workOrderCode?.toLowerCase().includes(q);
    const matchStatus = !statusFilter || wo.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-5">
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl text-sm font-semibold
          ${toast.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {toast.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/dashboard/stock/production')}
          className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-[#4C708E] hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} />
        </button>
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm" style={{ background: '#fee2e2' }}>
          <Package size={22} style={{ color: '#dc2626' }} />
        </div>
        <div className="flex-1">
          <h2 className="text-xl font-bold text-[#1E3448]">Work Orders</h2>
          <p className="text-sm text-[#8BAFC7]">Manage and track production work orders</p>
        </div>
        <button onClick={() => { setForm(emptyForm); setEditId(null); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white text-sm font-semibold shadow-sm transition-all hover:opacity-90"
          style={{ background: 'linear-gradient(135deg, #dc2626, #b91c1c)' }}>
          <Plus size={16} /> New Work Order
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total" value={workOrders.length} color="#64748b" icon={Package} />
        <StatCard label="Released" value={workOrders.filter(w => w.status === 'RELEASED').length} color="#1d4ed8" icon={Package} />
        <StatCard label="In Progress" value={workOrders.filter(w => w.status === 'IN_PROGRESS').length} color="#d97706" icon={Package} />
        <StatCard label="Completed" value={workOrders.filter(w => w.status === 'COMPLETED').length} color="#059669" icon={Package} />
      </div>

      {/* Search & Filter */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search work orders…"
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#D6E6F2] bg-[#F8FBFD] text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all" />
        </div>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
          className="rounded-xl border border-[#D6E6F2] bg-[#F8FBFD] px-3 py-2.5 text-sm text-gray-700 focus:outline-none appearance-none min-w-[150px]">
          <option value="">All Statuses</option>
          {WORK_ORDER_STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
        <button onClick={fetchAll}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#EBF4FB] text-[#4C708E] text-sm font-semibold hover:bg-[#D6E6F2] transition-colors">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Refresh
        </button>
      </div>

      {/* Add/Edit Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E8F1F8]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#fee2e2' }}>
                  <Package size={18} style={{ color: '#dc2626' }} />
                </div>
                <h3 className="font-bold text-[#1E3448]">{editId ? 'Edit Work Order' : 'New Work Order'}</h3>
              </div>
              <button onClick={() => { setShowForm(false); setForm(emptyForm); setEditId(null); }}
                className="w-8 h-8 rounded-lg bg-gray-100 text-gray-500 flex items-center justify-center hover:bg-gray-200 transition-colors">
                <X size={15} />
              </button>
            </div>
            <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <InputField label="Work Order Code" placeholder="e.g. WO-001" value={form.workOrderCode} onChange={v => set('workOrderCode', v)} icon={Hash} required />
              <InputField label="Quantity" placeholder="0" value={form.quantity} onChange={v => set('quantity', v)} type="number" icon={Package} />
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Product</label>
                <select value={form.productId} onChange={e => set('productId', e.target.value)}
                  className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none">
                  <option value="">-- Select Product --</option>
                  {products.map(p => <option key={p.id} value={p.id}>{p.name || i.itemName}</option>)}
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Production Plan</label>
                <select value={form.productionPlanId} onChange={e => set('productionPlanId', e.target.value)}
                  className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none">
                  <option value="">-- Select Plan --</option>
                  {plans.map(p => <option key={p.id} value={p.id}>{p.planCode}</option>)}
                </select>
              </div>
              <InputField label="Start Date" value={form.startDate} onChange={v => set('startDate', v)} type="date" icon={Calendar} />
              <InputField label="End Date" value={form.endDate} onChange={v => set('endDate', v)} type="date" icon={Calendar} />
              <div className="flex flex-col gap-1 sm:col-span-2">
                <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Status</label>
                <div className="flex gap-2 flex-wrap">
                  {WORK_ORDER_STATUSES.map(s => {
                    const c = STATUS_COLORS[s];
                    return (
                      <button key={s} onClick={() => set('status', s)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold border-2 transition-all"
                        style={form.status === s ? { background: c.bg, color: c.color, borderColor: c.color } : { background: 'white', color: '#64748b', borderColor: '#e2e8f0' }}>
                        {s.replace('_', ' ')}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="flex gap-3 px-6 pb-6">
              <button onClick={() => { setShowForm(false); setForm(emptyForm); setEditId(null); }}
                className="flex-1 py-2.5 rounded-xl border border-[#D6E6F2] text-[#4C708E] text-sm font-semibold hover:bg-[#EBF4FB] transition-colors">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-white text-sm font-semibold transition-all hover:opacity-90 disabled:opacity-60"
                style={{ background: 'linear-gradient(135deg, #dc2626, #b91c1c)' }}>
                <Save size={14} />{saving ? 'Saving…' : editId ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* List */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-2xl bg-[#fee2e2] flex items-center justify-center mb-4">
              <Package size={28} style={{ color: '#dc2626' }} />
            </div>
            <p className="font-bold text-[#1E3448] text-lg">No Work Orders Found</p>
            <p className="text-sm text-[#8BAFC7] mt-1">
              {search || statusFilter ? 'Adjust your filters' : 'Create the first work order'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[#E8F1F8]">
            {filtered.map(wo => (
              <div key={wo.id} className="flex items-center gap-4 px-5 py-4 hover:bg-[#F8FBFD] transition-colors group">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#fee2e2' }}>
                  <Package size={18} style={{ color: '#dc2626' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-bold text-[#1E3448] text-sm">{wo.workOrderCode}</p>
                    <StatusBadge status={wo.status} />
                  </div>
                  <div className="flex items-center gap-3 text-xs text-[#8BAFC7]">
                    {wo.quantity && <span className="flex items-center gap-1"><Package size={11} />Qty: {wo.quantity}</span>}
                    {(wo.startDate || wo.endDate) && (
                      <span className="flex items-center gap-1">
                        <Calendar size={11} />
                        {wo.startDate || '?'} → {wo.endDate || '?'}
                      </span>
                    )}
                    {(wo.product?.name || i.itemName) && <span>{wo.product.name || i.itemName}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => handleEdit(wo)}
                    className="w-8 h-8 rounded-lg bg-[#EBF4FB] text-[#4C708E] flex items-center justify-center hover:bg-[#D6E6F2] transition-colors">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => setDeleteId(wo.id)}
                    className="w-8 h-8 rounded-lg bg-red-50 text-red-400 flex items-center justify-center hover:bg-red-100 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
            <h3 className="text-center font-bold text-[#1E3448] text-lg mb-1">Delete Work Order?</h3>
            <p className="text-center text-sm text-[#8BAFC7] mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#D6E6F2] text-[#4C708E] text-sm font-semibold hover:bg-[#EBF4FB] transition-colors">Cancel</button>
              <button onClick={() => handleDelete(deleteId)}
                className="flex-1 py-2.5 rounded-xl bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition-colors">Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
