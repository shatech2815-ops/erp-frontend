import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Save, Plus, Trash2, Zap, Calendar, Hash,
  AlertCircle, CheckCircle, DollarSign, Package, BarChart2,
  ChevronDown, Building2,
} from 'lucide-react';

const LS_KEY_PLANS = 'srivaari_productionplans';
const LS_ITEMS     = 'srivaari_itemslist';

const PRODUCTION_STATUSES = ['PLANNED', 'IN_PROGRESS', 'CREATED', 'CANCELLED', 'RELEASED', 'COMPLETED'];
const PRIORITIES           = ['HIGH', 'MEDIUM', 'LOW'];
const WORK_ORDER_STATUSES  = ['CREATED', 'RELEASED', 'IN_PROGRESS', 'COMPLETED'];

const PRIORITY_COLORS = {
  HIGH:   { bg: '#fee2e2', color: '#dc2626' },
  MEDIUM: { bg: '#fef3c7', color: '#d97706' },
  LOW:    { bg: '#d1fae5', color: '#059669' },
};

const emptyPlan = {
  planCode: '', description: '', startDate: '', endDate: '',
  status: 'PLANNED', plant: '', priority: 'MEDIUM', estimatedCost: '',
  workOrders: [],
};

const emptyWO = {
  workOrderCode: '', quantity: '', productId: '', startDate: '', endDate: '', status: 'CREATED',
};

const InputField = ({ label, placeholder, value, onChange, type = 'text', icon: Icon, required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={14} /></span>}
      <input
        type={type} placeholder={placeholder} value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-9' : 'pl-4'} pr-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all`}
      />
    </div>
  </div>
);

const SelectField = ({ label, value, onChange, options, placeholder = 'Select…', required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <select value={value} onChange={e => onChange(e.target.value)}
      className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none">
      <option value="">{placeholder}</option>
      {options.map(o =>
        typeof o === 'string'
          ? <option key={o} value={o}>{o}</option>
          : <option key={o.value} value={o.value}>{o.label}</option>
      )}
    </select>
  </div>
);

const Section = ({ title, icon: Icon, children }) => (
  <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden mb-5">
    <div className="px-6 py-3 border-b border-[#E8F1F8] bg-gradient-to-r from-[#fee2e2] to-white flex items-center gap-2">
      {Icon && <Icon size={14} style={{ color: '#dc2626' }} />}
      <p className="text-xs font-bold text-[#dc2626] uppercase tracking-widest">{title}</p>
    </div>
    <div className="p-6">{children}</div>
  </div>
);

export default function ProductionPlanningPage() {
  const navigate = useNavigate();
  const [plan, setPlan]       = useState(emptyPlan);
  const [products, setProducts] = useState([]);
  const [saving, setSaving]   = useState(false);
  const [toast, setToast]     = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const set = (field, val) => setPlan(p => ({ ...p, [field]: val }));

  useEffect(() => {
    fetch('/api/items')
      .then(r => r.ok ? r.json() : [])
      .then(data => setProducts(data))
      .catch(() => {});
  }, []);

  const addWorkOrder = () => setPlan(p => ({ ...p, workOrders: [...p.workOrders, { ...emptyWO }] }));
  const removeWO = (i) => setPlan(p => ({ ...p, workOrders: p.workOrders.filter((_, idx) => idx !== i) }));
  const updateWO = (i, field, val) => setPlan(p => {
    const wos = [...p.workOrders];
    wos[i] = { ...wos[i], [field]: val };
    return { ...p, workOrders: wos };
  });

  const handleSubmit = async () => {
    if (!plan.planCode.trim()) { showToast('Plan Code is required', 'error'); return; }
    setSaving(true);
    const payload = {
      planCode:      plan.planCode,
      description:   plan.description,
      startDate:     plan.startDate || null,
      endDate:       plan.endDate   || null,
      status:        plan.status,
      plant:         plan.plant,
      priority:      plan.priority,
      estimatedCost: plan.estimatedCost ? Number(plan.estimatedCost) : null,
      workOrders: plan.workOrders.map(wo => ({
        workOrderCode: wo.workOrderCode,
        quantity:      wo.quantity ? Number(wo.quantity) : null,
        product:       wo.productId ? { id: Number(wo.productId) } : null,
        startDate:     wo.startDate || null,
        endDate:       wo.endDate   || null,
        status:        wo.status,
      })),
    };
    try {
      const res = await fetch('/api/production/plans', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      try {
        const raw = localStorage.getItem(LS_KEY_PLANS);
        const list = raw ? JSON.parse(raw) : [];
        localStorage.setItem(LS_KEY_PLANS, JSON.stringify([...list, saved]));
      } catch {}
      showToast('Production Plan saved!');
      setTimeout(() => setPlan(emptyPlan), 1500);
    } catch {
      try {
        const raw = localStorage.getItem(LS_KEY_PLANS);
        const list = raw ? JSON.parse(raw) : [];
        localStorage.setItem(LS_KEY_PLANS, JSON.stringify([...list, { ...payload, id: Date.now() }]));
      } catch {}
      showToast('Production Plan saved (offline)!');
      setTimeout(() => setPlan(emptyPlan), 1500);
    } finally {
      setSaving(false);
    }
  };

  const priorityColor = PRIORITY_COLORS[plan.priority] || PRIORITY_COLORS.MEDIUM;

  return (
    <div className="space-y-4 max-w-4xl">
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl text-sm font-semibold
          ${toast.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {toast.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/dashboard/stock/production')}
          className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-[#4C708E] hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} />
        </button>
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm" style={{ background: '#fee2e2' }}>
          <Zap size={22} style={{ color: '#dc2626' }} />
        </div>
        <div>
          <h2 className="text-xl font-bold text-[#1E3448]">Production Planning</h2>
          <p className="text-sm text-[#8BAFC7]">Create and manage production plans with work orders</p>
        </div>
      </div>

      {/* Plan Details */}
      <Section title="Plan Details" icon={BarChart2}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label="Plan Code" placeholder="e.g. PLAN-2024-001" value={plan.planCode} onChange={v => set('planCode', v)} icon={Hash} required />
          <SelectField label="Status" value={plan.status} onChange={v => set('status', v)} options={PRODUCTION_STATUSES} />
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide block mb-1">Description</label>
            <textarea value={plan.description} onChange={e => set('description', e.target.value)}
              placeholder="Optional plan description…" rows={2}
              className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all resize-none" />
          </div>
          <InputField label="Start Date" value={plan.startDate} onChange={v => set('startDate', v)} type="date" icon={Calendar} />
          <InputField label="End Date" value={plan.endDate} onChange={v => set('endDate', v)} type="date" icon={Calendar} />
          <InputField label="Plant / Facility" placeholder="e.g. Plant A" value={plan.plant} onChange={v => set('plant', v)} icon={Building2} />
          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Priority</label>
            <select value={plan.priority} onChange={e => set('priority', e.target.value)}
              className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none"
              style={{ color: priorityColor.color }}>
              {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <InputField label="Estimated Cost (₹)" placeholder="0.00" value={plan.estimatedCost} onChange={v => set('estimatedCost', v)} type="number" icon={DollarSign} />
        </div>
      </Section>

      {/* Work Orders */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden mb-5">
        <div className="px-6 py-3 border-b border-[#E8F1F8] bg-gradient-to-r from-[#fee2e2] to-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package size={14} style={{ color: '#dc2626' }} />
            <p className="text-xs font-bold text-[#dc2626] uppercase tracking-widest">Work Orders ({plan.workOrders.length})</p>
          </div>
          <button onClick={addWorkOrder}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white"
            style={{ background: '#dc2626' }}>
            <Plus size={12} /> Add Work Order
          </button>
        </div>
        <div className="p-6 space-y-4">
          {plan.workOrders.length === 0 ? (
            <div className="text-center py-8">
              <Package size={32} className="mx-auto mb-2 text-gray-300" />
              <p className="text-sm text-[#8BAFC7]">No work orders added yet</p>
              <button onClick={addWorkOrder} className="mt-3 text-xs text-[#dc2626] font-semibold hover:underline">
                + Add first work order
              </button>
            </div>
          ) : (
            plan.workOrders.map((wo, i) => (
              <div key={i} className="p-4 rounded-2xl border border-[#E8F1F8] bg-[#F8FBFD] relative">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-[#4C708E] uppercase tracking-wide">Work Order #{i + 1}</span>
                  <button onClick={() => removeWO(i)}
                    className="w-7 h-7 rounded-lg bg-red-50 text-red-400 flex items-center justify-center hover:bg-red-100 transition-colors">
                    <Trash2 size={13} />
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <InputField label="Work Order Code" placeholder="e.g. WO-001" value={wo.workOrderCode} onChange={v => updateWO(i, 'workOrderCode', v)} required />
                  <InputField label="Quantity" placeholder="0" value={wo.quantity} onChange={v => updateWO(i, 'quantity', v)} type="number" icon={Package} />
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Product</label>
                    <select value={wo.productId} onChange={e => updateWO(i, 'productId', e.target.value)}
                      className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none">
                      <option value="">-- Select Product --</option>
                      {products.map(p => <option key={p.id} value={p.id}>{p.name || i.itemName}</option>)}
                    </select>
                  </div>
                  <SelectField label="Status" value={wo.status} onChange={v => updateWO(i, 'status', v)} options={WORK_ORDER_STATUSES} />
                  <InputField label="Start Date" value={wo.startDate} onChange={v => updateWO(i, 'startDate', v)} type="date" icon={Calendar} />
                  <InputField label="End Date" value={wo.endDate} onChange={v => updateWO(i, 'endDate', v)} type="date" icon={Calendar} />
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Submit */}
      <div className="flex gap-3 pb-6">
        <button onClick={() => setPlan(emptyPlan)}
          className="flex-1 py-3 rounded-xl border border-[#D6E6F2] text-[#4C708E] font-semibold hover:bg-[#EBF4FB] transition-colors">
          Reset
        </button>
        <button onClick={handleSubmit} disabled={saving}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-white font-semibold shadow-sm transition-all hover:opacity-90 disabled:opacity-60"
          style={{ background: 'linear-gradient(135deg, #dc2626, #b91c1c)' }}>
          <Save size={16} />{saving ? 'Saving…' : 'Save Production Plan'}
        </button>
      </div>
    </div>
  );
}
