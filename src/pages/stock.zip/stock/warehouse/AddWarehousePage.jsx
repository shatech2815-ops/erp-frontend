import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  ArrowLeft, Save, Building2, MapPin, Mail, Phone,
  Plus, Trash2, AlertCircle, CheckCircle, Warehouse,
  Hash, Package,
} from 'lucide-react';

const LS_KEY   = 'srivaari_warehouselist';

const WAREHOUSE_TYPES = ['DISTRIBUTION', 'STORAGE', 'COLD_STORAGE'];

const emptyForm = {
  warehouseCode: '',
  warehouseName: '',
  warehouseType: '',
  city: '',
  state: '',
  country: '',
  contactPerson: '',
  contactEmail: '',
  totalArea: '',
  storageCapacity: '',
  locations: [],
};

const emptyLocation = { locationCode: '', locationName: '', description: '' };

const InputField = ({ label, placeholder, value, onChange, type = 'text', icon: Icon, required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={14} /></span>}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-9' : 'pl-4'} pr-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all`}
      />
    </div>
  </div>
);

const SelectField = ({ label, value, onChange, options, placeholder = 'Select…', required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none">
      <option value="">{placeholder}</option>
      {options.map(o =>
        typeof o === 'string'
          ? <option key={o} value={o}>{o.replace('_', ' ')}</option>
          : <option key={o.value} value={o.value}>{o.label}</option>
      )}
    </select>
  </div>
);

const Section = ({ title, icon: Icon, children }) => (
  <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden mb-5">
    <div className="px-6 py-3 border-b border-[#E8F1F8] bg-gradient-to-r from-[#fee2e2] to-white flex items-center gap-2">
      {Icon && <Icon size={14} style={{ color: '#dc2626' }} />}
      <p className="text-xs font-bold text-[#dc2626] uppercase tracking-widest">{title}</p>
    </div>
    <div className="p-6">{children}</div>
  </div>
);

export default function AddWarehousePage() {
  const navigate = useNavigate();
  const location = useLocation();
  const editWarehouse = location.state?.warehouse || null;

  const [form, setForm] = useState(editWarehouse ? {
    warehouseCode:   editWarehouse.warehouseCode   || '',
    warehouseName:   editWarehouse.warehouseName   || '',
    warehouseType:   editWarehouse.warehouseType   || '',
    city:            editWarehouse.city            || '',
    state:           editWarehouse.state           || '',
    country:         editWarehouse.country         || '',
    contactPerson:   editWarehouse.contactPerson   || '',
    contactEmail:    editWarehouse.contactEmail    || '',
    totalArea:       editWarehouse.totalArea       ?? '',
    storageCapacity: editWarehouse.storageCapacity ?? '',
    locations:       editWarehouse.locations       || [],
  } : emptyForm);

  const [saving, setSaving] = useState(false);
  const [toast, setToast]   = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const set = (field, val) => setForm(f => ({ ...f, [field]: val }));

  const addLocation = () => setForm(f => ({ ...f, locations: [...f.locations, { ...emptyLocation }] }));
  const removeLocation = (i) => setForm(f => ({ ...f, locations: f.locations.filter((_, idx) => idx !== i) }));
  const updateLocation = (i, field, val) => setForm(f => {
    const locs = [...f.locations];
    locs[i] = { ...locs[i], [field]: val };
    return { ...f, locations: locs };
  });

  const handleSubmit = async () => {
    if (!form.warehouseCode?.trim() && !form.name?.trim()) { showToast('Warehouse Code is required', 'error'); return; }
    setSaving(true);
    // Map frontend field names to backend Warehouse entity field names
    const payload = {
      name:             form.warehouseName || form.name || null,
      code:             form.warehouseCode || form.code || null,
      address:          form.address       || null,
      city:             form.city          || null,
      state:            form.state         || null,
      country:          form.country       || null,
      zipCode:          form.zipCode       || null,
      contactPerson:    form.contactPerson || null,
      phone:            form.phone         || null,
      email:            form.email         || null,
      type:             form.type          || null,
      capacity:         form.storageCapacity ? Number(form.storageCapacity) : (form.capacity ? Number(form.capacity) : null),
      utilizedCapacity: form.utilizedCapacity ? Number(form.utilizedCapacity) : null,
      active:           form.active !== undefined ? form.active : true,
      defaultWarehouse: form.defaultWarehouse || false,
      latitude:         form.latitude  ? parseFloat(form.latitude)  : null,
      longitude:        form.longitude ? parseFloat(form.longitude) : null,
      workingHours:     form.workingHours || null,
      remarks:          form.remarks      || null,
    };
    try {
      const method = editWarehouse ? 'PUT' : 'POST';
      const res    = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!res.ok) throw new Error();
      const saved = await res.json();
      try {
        const raw = localStorage.getItem('srivaari_warehouselist');
        const list = raw ? JSON.parse(raw) : [];
        const updated = editWarehouse
          ? list.map(w => w.id === saved.id ? saved : w)
          : [...list, saved];
        localStorage.setItem('srivaari_warehouselist', JSON.stringify(updated));
      } catch {}
      showToast(editWarehouse ? 'Warehouse updated!' : 'Warehouse saved!');
      setTimeout(() => navigate('/dashboard/stock/warehouse/warehouse-list'), 1200);
    } catch {
      try {
        const raw = localStorage.getItem('srivaari_warehouselist');
        const list = raw ? JSON.parse(raw) : [];
        const newItem = { ...payload, id: editWarehouse?.id || Date.now() };
        const updated = editWarehouse ? list.map(w => w.id === newItem.id ? newItem : w) : [...list, newItem];
        localStorage.setItem('srivaari_warehouselist', JSON.stringify(updated));
      } catch {}
      showToast(editWarehouse ? 'Warehouse updated (offline)!' : 'Warehouse saved (offline)!');
      setTimeout(() => navigate('/dashboard/stock/warehouse/warehouse-list'), 1200);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4 max-w-3xl">
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl text-sm font-semibold
          ${toast.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {toast.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/dashboard/stock/warehouse/warehouse-list')}
          className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-[#4C708E] hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} />
        </button>
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm" style={{ background: '#fee2e2' }}>
          <Warehouse size={22} style={{ color: '#dc2626' }} />
        </div>
        <div>
          <h2 className="text-xl font-bold text-[#1E3448]">{editWarehouse ? 'Edit Warehouse' : 'Add New Warehouse'}</h2>
          <p className="text-sm text-[#8BAFC7]">{editWarehouse ? 'Update warehouse details' : 'Register a new warehouse'}</p>
        </div>
      </div>

      {/* Basic Info */}
      <Section title="Warehouse Details" icon={Building2}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label="Warehouse Code" placeholder="e.g. WH-001" value={form.warehouseCode} onChange={v => set('warehouseCode', v)} icon={Hash} required />
          <InputField label="Warehouse Name" placeholder="e.g. Main Storage" value={form.warehouseName} onChange={v => set('warehouseName', v)} icon={Building2} />
          <SelectField label="Warehouse Type" value={form.warehouseType} onChange={v => set('warehouseType', v)} options={WAREHOUSE_TYPES} placeholder="Select type…" />
          <InputField label="Total Area (sq ft)" placeholder="0" value={form.totalArea} onChange={v => set('totalArea', v)} type="number" icon={Package} />
          <InputField label="Storage Capacity" placeholder="0" value={form.storageCapacity} onChange={v => set('storageCapacity', v)} type="number" icon={Package} />
        </div>
      </Section>

      {/* Location */}
      <Section title="Address" icon={MapPin}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label="City" placeholder="City" value={form.city} onChange={v => set('city', v)} icon={MapPin} />
          <InputField label="State" placeholder="State" value={form.state} onChange={v => set('state', v)} />
          <InputField label="Country" placeholder="Country" value={form.country} onChange={v => set('country', v)} />
        </div>
      </Section>

      {/* Contact */}
      <Section title="Contact Info" icon={Mail}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label="Contact Person" placeholder="Name" value={form.contactPerson} onChange={v => set('contactPerson', v)} />
          <InputField label="Contact Email" placeholder="email@example.com" value={form.contactEmail} onChange={v => set('contactEmail', v)} type="email" icon={Mail} />
        </div>
      </Section>

      {/* Locations */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden mb-5">
        <div className="px-6 py-3 border-b border-[#E8F1F8] bg-gradient-to-r from-[#fee2e2] to-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin size={14} style={{ color: '#dc2626' }} />
            <p className="text-xs font-bold text-[#dc2626] uppercase tracking-widest">Warehouse Locations</p>
          </div>
          <button onClick={addLocation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white"
            style={{ background: '#dc2626' }}>
            <Plus size={12} /> Add Location
          </button>
        </div>
        <div className="p-6 space-y-4">
          {form.locations.length === 0 ? (
            <div className="text-center py-8">
              <MapPin size={32} className="mx-auto mb-2 text-gray-300" />
              <p className="text-sm text-[#8BAFC7]">No locations added yet</p>
              <button onClick={addLocation} className="mt-3 text-xs text-[#dc2626] font-semibold hover:underline">+ Add first location</button>
            </div>
          ) : (
            form.locations.map((loc, i) => (
              <div key={i} className="p-4 rounded-xl border border-[#E8F1F8] bg-[#F8FBFD] relative">
                <button onClick={() => removeLocation(i)}
                  className="absolute top-3 right-3 w-7 h-7 rounded-lg bg-red-50 text-red-400 flex items-center justify-center hover:bg-red-100 transition-colors">
                  <Trash2 size={13} />
                </button>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <InputField label="Location Code" placeholder="e.g. A1" value={loc.locationCode} onChange={v => updateLocation(i, 'locationCode', v)} required />
                  <InputField label="Location Name" placeholder="e.g. Rack A1" value={loc.locationName} onChange={v => updateLocation(i, 'locationName', v)} required />
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Description</label>
                    <input
                      value={loc.description}
                      onChange={e => updateLocation(i, 'description', e.target.value)}
                      placeholder="Optional"
                      className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all"
                    />
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Submit */}
      <div className="flex gap-3 pb-6">
        <button onClick={() => navigate('/dashboard/stock/warehouse/warehouse-list')}
          className="flex-1 py-3 rounded-xl border border-[#D6E6F2] text-[#4C708E] font-semibold hover:bg-[#EBF4FB] transition-colors">
          Cancel
        </button>
        <button onClick={handleSubmit} disabled={saving}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-white font-semibold shadow-sm transition-all hover:opacity-90 disabled:opacity-60"
          style={{ background: 'linear-gradient(135deg, #dc2626, #b91c1c)' }}>
          <Save size={16} />
          {saving ? 'Saving…' : editWarehouse ? 'Update Warehouse' : 'Save Warehouse'}
        </button>
      </div>
    </div>
  );
}
