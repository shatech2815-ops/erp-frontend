import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, MapPin, Save, Plus, Trash2, Building2,
  AlertCircle, CheckCircle, Search, Hash,
} from 'lucide-react';


const emptyForm = {
  locationCode: '',
  locationName: '',
  description: '',
  warehouseId: '',
};

const InputField = ({ label, placeholder, value, onChange, icon: Icon, required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={14} /></span>}
      <input
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-9' : 'pl-4'} pr-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all`}
      />
    </div>
  </div>
);

export default function LocationMappingPage() {
  const navigate = useNavigate();
  const [warehouses, setWarehouses] = useState([]);
  const [locations, setLocations]   = useState([]);
  const [form, setForm]             = useState(emptyForm);
  const [search, setSearch]         = useState('');
  const [saving, setSaving]         = useState(false);
  const [toast, setToast]           = useState(null);
  const [deleteId, setDeleteId]     = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const set = (field, val) => setForm(f => ({ ...f, [field]: val }));

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [wRes, lRes] = await Promise.all([        ]);
        if (wRes.ok) setWarehouses(await wRes.json());
        if (lRes.ok) setLocations(await lRes.json());
      } catch {
        try {
          const raw = localStorage.getItem('srivaari_warehouselist');
          if (raw) setWarehouses(JSON.parse(raw));
        } catch {}
      }
    };
    fetchData();
  }, []);

  const handleSave = () => {
    if (!form.warehouseId || !form.locationCode) { showToast('Warehouse and Location Code are required.', 'error'); return; }
    setSaving(true);
    let stored = [];
    try { const d = localStorage.getItem(LS_KEY); if (d) stored = JSON.parse(d); } catch {}
    const updated = [...stored, { ...form, id: Date.now() }];
    setLocations(updated);
    try { localStorage.setItem(LS_KEY, JSON.stringify(updated)); } catch {}
    setForm({ warehouseId: '', locationCode: '', locationName: '', description: '' });
    showToast('Location added.');
    setSaving(false);
  };

  const handleDelete = (id) => {
    let stored = [];
    try { const d = localStorage.getItem(LS_KEY); if (d) stored = JSON.parse(d); } catch {}
    const updated = stored.filter(l => l.id !== id);
    setLocations(updated);
    try { localStorage.setItem(LS_KEY, JSON.stringify(updated)); } catch {}
    showToast('Location deleted.');
  };

  const filtered = locations.filter(l => {
    const q = search.toLowerCase();
    return !q || l.locationCode?.toLowerCase().includes(q) || l.locationName?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-5 max-w-4xl">
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl text-sm font-semibold
          ${toast.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {toast.type === 'success' ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/dashboard/stock/warehouse')}
          className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-[#4C708E] hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} />
        </button>
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm" style={{ background: '#fee2e2' }}>
          <MapPin size={22} style={{ color: '#dc2626' }} />
        </div>
        <div>
          <h2 className="text-xl font-bold text-[#1E3448]">Location Mapping</h2>
          <p className="text-sm text-[#8BAFC7]">Map locations to warehouses</p>
        </div>
      </div>

      {/* Add Form */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
        <div className="px-6 py-3 border-b border-[#E8F1F8] bg-gradient-to-r from-[#fee2e2] to-white flex items-center gap-2">
          <MapPin size={14} style={{ color: '#dc2626' }} />
          <p className="text-xs font-bold text-[#dc2626] uppercase tracking-widest">Add New Location</p>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <InputField label="Location Code" placeholder="e.g. A1" value={form.locationCode} onChange={v => set('locationCode', v)} icon={Hash} required />
            <InputField label="Location Name" placeholder="e.g. Rack A1" value={form.locationName} onChange={v => set('locationName', v)} required />
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
                Warehouse <span className="text-red-400">*</span>
              </label>
              <select
                value={form.warehouseId}
                onChange={e => set('warehouseId', e.target.value)}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all appearance-none">
                <option value="">-- Select Warehouse --</option>
                {warehouses.map(w => (
                  <option key={w.id} value={w.id}>{w.warehouseName} ({w.warehouseCode})</option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Description</label>
              <textarea
                value={form.description}
                onChange={e => set('description', e.target.value)}
                placeholder="Optional description"
                rows={3}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#dc2626]/30 focus:border-[#dc2626] transition-all resize-none"
              />
            </div>
          </div>
          <button onClick={handleSave} disabled={saving}
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-white font-semibold shadow-sm transition-all hover:opacity-90 disabled:opacity-60"
            style={{ background: 'linear-gradient(135deg, #dc2626, #b91c1c)' }}>
            <Save size={16} />{saving ? 'Saving…' : 'Save Location'}
          </button>
        </div>
      </div>

      {/* Location List */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
        <div className="px-6 py-4 border-b border-[#E8F1F8] flex items-center justify-between">
          <p className="text-sm font-bold text-[#1E3448]">Mapped Locations ({filtered.length})</p>
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search…"
              className="pl-8 pr-4 py-2 rounded-xl border border-[#D6E6F2] bg-[#F8FBFD] text-sm text-gray-700 focus:outline-none w-48 focus:ring-2 focus:ring-[#dc2626]/20" />
          </div>
        </div>
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <MapPin size={28} className="text-gray-300 mb-2" />
            <p className="text-sm text-[#8BAFC7]">{search ? 'No results found' : 'No locations mapped yet'}</p>
          </div>
        ) : (
          <div className="divide-y divide-[#E8F1F8]">
            {filtered.map(loc => (
              <div key={loc.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-[#F8FBFD] group transition-colors">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#fee2e2' }}>
                  <MapPin size={16} style={{ color: '#dc2626' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#1E3448] text-sm">{loc.locationName}</p>
                  <div className="flex items-center gap-3 text-xs text-[#8BAFC7]">
                    <span className="font-mono">{loc.locationCode}</span>
                    {loc.warehouse && (
                      <span className="flex items-center gap-1">
                        <Building2 size={10} />{loc.warehouse.warehouseName || loc.warehouse.warehouseCode}
                      </span>
                    )}
                  </div>
                </div>
                <button onClick={() => setDeleteId(loc.id)}
                  className="w-8 h-8 rounded-lg bg-red-50 text-red-400 flex items-center justify-center opacity-0 group-hover:opacity-100 hover:bg-red-100 transition-all">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
            <h3 className="text-center font-bold text-[#1E3448] text-lg mb-1">Remove Location?</h3>
            <p className="text-center text-sm text-[#8BAFC7] mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#D6E6F2] text-[#4C708E] text-sm font-semibold hover:bg-[#EBF4FB] transition-colors">
                Cancel
              </button>
              <button onClick={() => handleDelete(deleteId)}
                className="flex-1 py-2.5 rounded-xl bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition-colors">
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
