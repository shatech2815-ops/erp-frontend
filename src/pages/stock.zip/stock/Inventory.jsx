import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Package, BarChart2, ArrowLeftRight, Sliders } from 'lucide-react';

const INVENTORY_SECTIONS = [
  {
    label: 'Stock Levels',
    desc: 'View and manage current stock quantities per warehouse',
    icon: BarChart2,
    route: '/dashboard/stock/inventory/stock-levels',
    color: '#4C708E',
    bg: '#EBF4FB',
  },
  {
    label: 'Item Catalog',
    desc: 'Manage items, categories, units and pricing',
    icon: Package,
    route: '/dashboard/stock/inventory/item-catalog',
    color: '#059669',
    bg: '#d1fae5',
  },
  {
    label: 'Stock Adjustment',
    desc: 'Record stock-in, stock-out and adjustments',
    icon: Sliders,
    route: '/dashboard/stock/inventory/stock-adjustment',
    color: '#d97706',
    bg: '#fef3c7',
  },
  {
    label: 'Stock Transfer',
    desc: 'Transfer stock between warehouses',
    icon: ArrowLeftRight,
    route: '/dashboard/stock/inventory/stock-transfer',
    color: '#dc2626',
    bg: '#fee2e2',
  },
];

export default function Inventory() {
  const navigate = useNavigate();

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm"
        >
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4C708E] to-[#8BAFC7] flex items-center justify-center">
            <Package size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Inventory</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Stock levels, adjustments and transfers</p>
          </div>
        </div>
      </div>

      {/* ✅ Changed: grid replaced with flex-col for list layout */}
      <div className="flex flex-col gap-4">
        {INVENTORY_SECTIONS.map((sec, idx) => {
          const Icon = sec.icon;
          return (
            <button
              key={idx}
              onClick={() => navigate(sec.route)}
              className="relative flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8] hover:shadow-xl hover:-translate-y-1 transition-all duration-200 group text-left overflow-hidden"
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all duration-200 group-hover:scale-110"
                style={{ background: sec.bg }}
              >
                <Icon size={24} style={{ color: sec.color }} />
              </div>
              <div className="flex-1">
                <p className="font-bold text-[#1E3448] text-base group-hover:text-[#4C708E] transition-colors">{sec.label}</p>
                <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{sec.desc}</p>
              </div>
              <span className="text-2xl font-black opacity-10 absolute right-4 top-1/2 -translate-y-1/2" style={{ color: sec.color }}>
                {idx + 1}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}