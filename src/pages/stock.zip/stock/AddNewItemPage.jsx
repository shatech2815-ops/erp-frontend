import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  ArrowLeft, Save, Package, Tag, DollarSign,
  Layers, AlertCircle, Hash, CheckCircle, XCircle,
} from 'lucide-react';

const API_ITEMS      = '/api/items';
const API_CATEGORIES = '/api/categories/getall';
const UNITS = ['KG', 'LITER', 'NOS', 'BOX', 'PACK'];

const emptyForm = {
  name:         '',
  sku:          '',
  description:  '',
  price:        '',
  costPrice:    '',
  quantity:     '',
  reorderLevel: '',
  unit:         '',
  brand:        '',
  categoryId:   '',
  active:       true,
  discontinued: false,
};

const InputField = ({ label, placeholder, value, onChange, type = 'text', icon: Icon, required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]"><Icon size={14} /></span>}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={`w-full rounded-xl border border-[#D6E6F2] bg-white ${Icon ? 'pl-9' : 'pl-4'} pr-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#ef4444]/30 focus:border-[#ef4444] transition-all`}
      />
    </div>
  </div>
);

const SelectField = ({ label, value, onChange, options, placeholder = 'Select…', required }) => (
  <div className="flex flex-col gap-1">
    <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#ef4444]/30 focus:border-[#ef4444] transition-all appearance-none"
    >
      <option value="">{placeholder}</option>
      {options.map(o =>
        typeof o === 'string'
          ? <option key={o} value={o}>{o}</option>
          : <option key={o.value} value={o.value}>{o.label}</option>
      )}
    </select>
  </div>
);

const Section = ({ title, children }) => (
  <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden mb-5">
    <div className="px-6 py-3 border-b border-[#E8F1F8] bg-gradient-to-r from-[#EBF4FB] to-white">
      <p className="text-xs font-bold text-[#4C708E] uppercase tracking-widest">{title}</p>
    </div>
    <div className="p-6">{children}</div>
  </div>
);

export default function AddNewItemPage() {
  const navigate  = useNavigate();
  const location  = useLocation();
  const editItem  = location.state?.item || null;

  const [form, setForm]           = useState(editItem ? {
    name:         editItem.name         || '',
    sku:          editItem.sku          || '',
    description:  editItem.description  || '',
    price:        editItem.price        ?? '',
    costPrice:    editItem.costPrice    ?? '',
    quantity:     editItem.quantity     ?? '',
    reorderLevel: editItem.reorderLevel ?? '',
    unit:         editItem.unit         || '',
    brand:        editItem.brand        || '',
    categoryId:   editItem.category?.id ?? editItem.categoryId ?? '',
    active:       editItem.active       ?? true,
    discontinued: editItem.discontinued ?? false,
  } : emptyForm);
  const [categories, setCategories] = useState([]);
  const [saving, setSaving]         = useState(false);
  const [toast, setToast]           = useState(null);
  const [useApi, setUseApi]         = useState(false);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => {
    fetch(API_CATEGORIES)
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data) { setCategories(data); setUseApi(true); } })
      .catch(() => {
        try { const d = localStorage.getItem('srivaari_categories'); if (d) setCategories(JSON.parse(d)); } catch {}
      });
  }, []);

  const f = (key, val) => setForm(p => ({ ...p, [key]: val }));

  const handleSave = async () => {
    if (!form.sku.trim() || !form.name.trim()) {
      showToast('SKU and Item Name are required.', 'error'); return;
    }
    setSaving(true);

    // Build payload matching backend Item entity exactly
    const payload = {
      name:         form.name.trim(),
      sku:          form.sku.trim(),
      description:  form.description.trim() || null,
      price:        form.price !== '' ? parseFloat(form.price) : null,
      costPrice:    form.costPrice !== '' ? parseFloat(form.costPrice) : null,
      quantity:     form.quantity !== '' ? parseInt(form.quantity) : null,
      reorderLevel: form.reorderLevel !== '' ? parseInt(form.reorderLevel) : null,
      unit:         form.unit || null,
      brand:        form.brand.trim() || null,
      active:       form.active,
      discontinued: form.discontinued,
      category:     form.categoryId ? { id: parseInt(form.categoryId) } : null,
    };

    try {
      const isEdit = !!editItem;
      const url = isEdit ? `${API_ITEMS}/${editItem.id}` : API_ITEMS;
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        showToast(isEdit ? 'Item updated successfully!' : 'Item created successfully!');
        setTimeout(() => navigate('/dashboard/stock/items/item-list'), 1200);
        setSaving(false);
        return;
      }
    } catch {}

    // Fallback to localStorage
    try {
      const stored = JSON.parse(localStorage.getItem('srivaari_itemslist') || '[]');
      const catName = categories.find(c => String(c.id) === String(form.categoryId))?.name || '';
      let updated;
      if (editItem) {
        updated = stored.map(it => it.id === editItem.id ? { ...it, ...payload, categoryName: catName } : it);
      } else {
        updated = [...stored, { ...payload, id: Date.now(), categoryName: catName }];
      }
      localStorage.setItem('srivaari_itemslist', JSON.stringify(updated));
      showToast(editItem ? 'Item updated!' : 'Item saved!');
      setTimeout(() => navigate('/dashboard/stock/items/item-list'), 1200);
    } catch { showToast('Error saving item.', 'error'); }
    setSaving(false);
  };

  const catOptions = categories.map(c => ({ value: String(c.id), label: c.name }));

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      {toast && (
        <div className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-2xl shadow-xl text-sm font-semibold flex items-center gap-2 ${toast.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
          {toast.type === 'error' ? <XCircle size={15} /> : <CheckCircle size={15} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#ef4444] to-[#f87171] flex items-center justify-center shadow-md">
            <Package size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">{editItem ? 'Edit Item' : 'Add New Item'}</h1>
            <p className="text-xs text-[#8BAFC7]">Stock Management › Items › {editItem ? 'Edit' : 'Add New'}</p>
          </div>
        </div>
      </div>

      {/* Basic Info */}
      <Section title="Basic Information">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <InputField label="SKU" placeholder="e.g. ITM-001" value={form.sku} onChange={v => f('sku', v)} icon={Hash} required />
          <InputField label="Item Name" placeholder="Item Name" value={form.name} onChange={v => f('name', v)} icon={Package} required />
          <InputField label="Brand" placeholder="Brand Name" value={form.brand} onChange={v => f('brand', v)} icon={Tag} />
        </div>
        <div className="mt-4">
          <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide block mb-1">Description</label>
          <textarea
            placeholder="Item description…"
            value={form.description}
            onChange={e => f('description', e.target.value)}
            rows={3}
            className="w-full rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#ef4444]/30 focus:border-[#ef4444] transition-all resize-none"
          />
        </div>
      </Section>

      {/* Pricing */}
      <Section title="Pricing">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <InputField label="Price (₹)" placeholder="Selling Price" value={form.price} onChange={v => f('price', v)} type="number" icon={DollarSign} />
          <InputField label="Cost Price (₹)" placeholder="Purchase Cost" value={form.costPrice} onChange={v => f('costPrice', v)} type="number" icon={DollarSign} />
        </div>
      </Section>

      {/* Stock & Classification */}
      <Section title="Stock & Classification">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          <SelectField label="Unit" value={form.unit} onChange={v => f('unit', v)} options={UNITS} placeholder="Select Unit" required />
          <SelectField label="Category" value={form.categoryId} onChange={v => f('categoryId', v)} options={catOptions} placeholder="Select Category" />
          <InputField label="Quantity" placeholder="Current Stock" value={form.quantity} onChange={v => f('quantity', v)} type="number" icon={Layers} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
          <InputField label="Reorder Level" placeholder="Min Stock Before Reorder" value={form.reorderLevel} onChange={v => f('reorderLevel', v)} type="number" icon={AlertCircle} />
        </div>
      </Section>

      {/* Status */}
      <Section title="Status">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide block mb-2">Active Status</label>
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => f('active', true)}
                className={`px-6 py-3 rounded-xl text-sm font-semibold border-2 transition-all ${form.active ? 'bg-emerald-500 text-white border-emerald-500 shadow-md' : 'bg-white text-gray-500 border-[#D6E6F2] hover:border-emerald-300'}`}>
                ✓ Active
              </button>
              <button type="button" onClick={() => f('active', false)}
                className={`px-6 py-3 rounded-xl text-sm font-semibold border-2 transition-all ${!form.active ? 'bg-[#ef4444] text-white border-[#ef4444] shadow-md' : 'bg-white text-gray-500 border-[#D6E6F2] hover:border-red-300'}`}>
                ✕ Inactive
              </button>
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide block mb-2">Discontinued</label>
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => f('discontinued', false)}
                className={`px-6 py-3 rounded-xl text-sm font-semibold border-2 transition-all ${!form.discontinued ? 'bg-emerald-500 text-white border-emerald-500 shadow-md' : 'bg-white text-gray-500 border-[#D6E6F2] hover:border-emerald-300'}`}>
                In Production
              </button>
              <button type="button" onClick={() => f('discontinued', true)}
                className={`px-6 py-3 rounded-xl text-sm font-semibold border-2 transition-all ${form.discontinued ? 'bg-amber-500 text-white border-amber-500 shadow-md' : 'bg-white text-gray-500 border-[#D6E6F2] hover:border-amber-300'}`}>
                Discontinued
              </button>
            </div>
          </div>
        </div>
      </Section>

      {/* Save Button */}
      <div className="flex justify-end gap-3">
        <button onClick={() => navigate(-1)} className="px-6 py-3 rounded-xl border border-[#D6E6F2] bg-white text-sm font-semibold text-gray-600 hover:bg-[#EBF4FB] transition-colors">
          Cancel
        </button>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-8 py-3 rounded-xl bg-[#ef4444] text-white text-sm font-semibold hover:bg-red-600 transition-colors shadow-lg disabled:opacity-60"
        >
          {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={15} />}
          {editItem ? 'Update Item' : 'Save Item'}
        </button>
      </div>
    </div>
  );
}
