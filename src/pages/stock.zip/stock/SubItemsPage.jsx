import React from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import {
  ArrowRight, ArrowLeft,
  ShoppingCart, Users, Package, ClipboardList, BarChart2, Settings,
  Tag, FileText, CreditCard, Activity, Building2, Warehouse,
  Wrench, Briefcase, Zap, DollarSign, TrendingUp, ChevronRight,
} from 'lucide-react';

// ── Section icons ─────────────────────────────────────────────────────────────
const SECTION_ICONS = {
  'purchase-orders': ShoppingCart,
  vendors:           Users,
  inventory:         Package,
  requisitions:      ClipboardList,
  reports:           BarChart2,
  settings:          Settings,
  contracts:         FileText,
  invoices:          CreditCard,
  performance:       Activity,
  clients:           Building2,
  leads:             TrendingUp,
  opportunities:     Briefcase,
  orders:            ShoppingCart,
  service:           Wrench,
  financials:        DollarSign,
  payments:          CreditCard,
  expenses:          Tag,
  stock:             Warehouse,
  items:             Package,
  warehouse:         Warehouse,
  production:        Zap,
};

// ── Per-module colour palettes ────────────────────────────────────────────────
const MODULE_META = {
  purchase:      { gradient: 'from-violet-500 to-purple-600',  light: '#ede9fe', accent: '#7c3aed', text: '#5b21b6' },
  vendor:        { gradient: 'from-[#4C708E] to-[#6B92AB]',    light: '#EBF4FB', accent: '#4C708E', text: '#2D4A5E' },
  client:        { gradient: 'from-emerald-500 to-teal-500',   light: '#d1fae5', accent: '#059669', text: '#065f46' },
  accounts:      { gradient: 'from-amber-400 to-orange-500',   light: '#fef3c7', accent: '#d97706', text: '#92400e' },
  stock:         { gradient: 'from-red-500 to-rose-600',       light: '#fee2e2', accent: '#dc2626', text: '#991b1b' },
  inventorymgmt: { gradient: 'from-pink-500 to-fuchsia-600',   light: '#fce7f3', accent: '#db2777', text: '#9d174d' },
};

// ── Section colour palettes (cycling) ─────────────────────────────────────────
const CARD_PALETTES = [
  { bg: '#EBF4FB', icon: '#4C708E', border: '#4C708E20' },
  { bg: '#d1fae5', icon: '#059669', border: '#05966920' },
  { bg: '#fef3c7', icon: '#d97706', border: '#d9770620' },
  { bg: '#ede9fe', icon: '#7c3aed', border: '#7c3aed20' },
  { bg: '#fee2e2', icon: '#dc2626', border: '#dc262620' },
  { bg: '#fce7f3', icon: '#db2777', border: '#db277720' },
];

const allModules = {
  purchase: {
    label: 'Purchase Management',
    subtitle: 'Manage purchase orders, vendors & inventory',
    sections: [
      { id: 'purchase-orders', label: 'Purchase Orders', desc: 'Create and track purchase orders',        items: [{ label: 'PO List', route: '/dashboard/purchase/purchase-orders/po-list' },{ label: 'Create PO', route: '/dashboard/purchase/purchase-orders/create-po' },{ label: 'PO Status Tracker', route: '/dashboard/purchase/purchase-orders/po-status-tracker' }] },
      { id: 'vendors',         label: 'Vendors',         desc: 'Manage supplier relationships',           items: [{ label: 'Vendor List', route: '/dashboard/purchase/vendors/list' },{ label: 'Vendor Performance' },{ label: 'Add New Vendor', route: '/dashboard/purchase/vendors/add' }] },
      { id: 'inventory',       label: 'Inventory',       desc: 'Track stock levels and items',            items: [{ label: 'Item Catalog', route: '/dashboard/purchase/inventory/item-catalog' },{ label: 'Stock Levels', route: '/dashboard/purchase/inventory/stock-levels' },{ label: 'Item Requests', route: '/dashboard/purchase/inventory/item-requests' }] },
      { id: 'requisitions',    label: 'Requisitions',    desc: 'Requisition approvals and workflows',     items: [{ label: 'Requisition List', route: '/dashboard/purchase/requisitions/req-list' },{ label: 'New Requisition', route: '/dashboard/purchase/requisitions/new-requisition' },{ label: 'Approval Workflow', route: '/dashboard/purchase/requisitions/approval-workflow' }] },
      { id: 'reports',         label: 'Reports',         desc: 'Analytics and performance reports',       route: '/dashboard/purchase/reports', items: [{ label: 'PO Reports', route: '/dashboard/purchase/reports/po-reports' },{ label: 'Vendor Performance Report', route: '/dashboard/purchase/reports/vendor-performance' },{ label: 'Inventory Report', route: '/dashboard/purchase/reports/inventory-report' }] },
      { id: 'settings',        label: 'Settings',        desc: 'Configure purchase preferences',          items: [{ label: 'Approval Matrix', route: '/dashboard/purchase/settings/approval-matrix' },{ label: 'PO Templates', route: '/dashboard/purchase/settings/po-templates' },{ label: 'Vendor Categories', route: '/dashboard/purchase/settings/vendor-categories' }] },
    ],
  },
  vendor: {
    label: 'Vendor Management',
    subtitle: 'Contracts, invoices and vendor performance',
    sections: [
      { id: 'vendors',    label: 'Vendors',    desc: 'All registered vendor profiles',       items: [{ label: 'Vendor List', route: '/dashboard/vendor/vendors/list' },{ label: 'Add New Vendor', route: '/dashboard/vendor/vendors/add' },{ label: 'Vendor Categories', route: '/dashboard/vendor/vendors/categories' }] },
      { id: 'contracts',  label: 'Contracts',  desc: 'Contracts, templates and renewals',    items: [{ label: 'Contract List', route: '/dashboard/vendor/contracts/list' },{ label: 'Add New Contract', route: '/dashboard/vendor/contracts/add' },{ label: 'Contract Templates', route: '/dashboard/vendor/contracts/templates' }] },
      { id: 'invoices',   label: 'Invoices',   desc: 'Billing, payments and history',        items: [{ label: 'Invoice List', route: '/dashboard/vendor/invoices/list' },{ label: 'Generate Invoice', route: '/dashboard/vendor/invoices/generate' },{ label: 'Payment History', route: '/dashboard/vendor/invoices/payments' }] },
      { id: 'performance',label: 'Performance',desc: 'Scorecards, SLAs and analytics',       route: '/dashboard/vendor/performance', items: [{ label: 'Vendor Scorecard', route: '/dashboard/vendor/performance/vendor-scorecard' },{ label: 'Performance Reports', route: '/dashboard/vendor/performance/performance-reports' },{ label: 'SLA Tracking', route: '/dashboard/vendor/performance/sla-tracking' }] },
      { id: 'reports',    label: 'Reports',    desc: 'Vendor and contract analytics',        route: '/dashboard/vendor/reports',     items: [{ label: 'Vendor Performance Report', route: '/dashboard/vendor/reports/vendor-performance' },{ label: 'Contract Expiry Report', route: '/dashboard/vendor/reports/contract-expiry' },{ label: 'Invoice Payment Report', route: '/dashboard/vendor/reports/invoice-payment' }] },
      { id: 'settings',   label: 'Settings',   desc: 'Vendor types, terms and preferences',  route: '/dashboard/vendor/settings',    items: [{ label: 'Vendor Types', route: '/dashboard/vendor/settings/vendor-types' },{ label: 'Contract Terms', route: '/dashboard/vendor/settings/contract-terms' },{ label: 'Payment Terms', route: '/dashboard/vendor/settings/payment-terms' }] },
    ],
  },
  client: {
    label: 'Client Management',
    subtitle: 'Leads, orders, service and client relations',
    sections: [
      { id: 'clients',      label: 'Clients',       desc: 'Client profiles and categories',        items: [{ label: 'Client List', route: '/dashboard/client/clients/list' },{ label: 'Add New Client', route: '/dashboard/client/clients/add' },{ label: 'Client Categories', route: '/dashboard/client/clients/categories' },{ label: 'Client Contacts', route: '/dashboard/client/clients/contacts' }] },
      { id: 'leads',        label: 'Leads',         desc: 'Track and convert incoming leads',      items: [{ label: 'Lead List' },{ label: 'Add New Lead' },{ label: 'Lead Sources' },{ label: 'Lead Conversion' }] },
      { id: 'opportunities',label: 'Opportunities', desc: 'Sales pipeline and quotations',         items: [{ label: 'Opportunity List' },{ label: 'Add New Opportunity' },{ label: 'Sales Pipeline' },{ label: 'Quotation Management' }] },
      { id: 'orders',       label: 'Orders',        desc: 'Order status and delivery tracking',    items: [{ label: 'Order List' },{ label: 'Create Order' },{ label: 'Order Status' },{ label: 'Delivery Schedule' }] },
      { id: 'service',      label: 'Service',       desc: 'Requests, complaints and warranty',     items: [{ label: 'Service Requests' },{ label: 'Service History' },{ label: 'Warranty Management' },{ label: 'Complaints' }] },
      { id: 'reports',      label: 'Reports',       desc: 'Sales, client and order analytics',     items: [{ label: 'Client Report' },{ label: 'Sales Report' },{ label: 'Order Report' },{ label: 'Client Feedback Report' }] },
    ],
  },
  accounts: {
    label: 'Accounts Management',
    subtitle: 'Financials, invoices, payments and GST',
    sections: [
      { id: 'financials',label: 'Financials', desc: 'Ledger, trial balance and reports',     items: [{ label: 'Dashboard', route: '/dashboard/accounts/financials/dashboard' },{ label: 'General Ledger', route: '/dashboard/accounts/financials/ledger' },{ label: 'Trial Balance', route: '/dashboard/accounts/financials/trial-balance' },{ label: 'Financial Reports', route: '/dashboard/accounts/financials/reports' }] },
      { id: 'invoices',  label: 'Invoices',   desc: 'Create, track and manage invoices',     items: [{ label: 'Invoice List', route: '/dashboard/accounts/invoices/list' },{ label: 'Create Invoice', route: '/dashboard/accounts/invoices/create' },{ label: 'Invoice Tracking', route: '/dashboard/accounts/invoices/tracking' },{ label: 'Payment Receipts', route: '/dashboard/accounts/invoices/receipts' }] },
      { id: 'payments',  label: 'Payments',   desc: 'Payments, modes and reconciliation',    items: [{ label: 'Payment List', route: '/dashboard/accounts/payments/list' },{ label: 'Make Payment', route: '/dashboard/accounts/payments/make' },{ label: 'Payment Modes', route: '/dashboard/accounts/payments/modes' },{ label: 'Bank Reconciliation', route: '/dashboard/accounts/payments/reconciliation' }] },
      { id: 'expenses',  label: 'Expenses',   desc: 'Expense tracking and categories',       items: [{ label: 'Expense List', route: '/dashboard/accounts/expenses/list' },{ label: 'Add Expense', route: '/dashboard/accounts/expenses/add' },{ label: 'Expense Categories', route: '/dashboard/accounts/expenses/categories' },{ label: 'Expense Reports', route: '/dashboard/accounts/expenses/reports' }] },
      { id: 'vendors',   label: 'Vendors',    desc: 'Vendor payments and invoices',          items: [{ label: 'Vendor List', route: '/dashboard/accounts/vendors/list' },{ label: 'Vendor Payments', route: '/dashboard/accounts/vendors/payments' },{ label: 'Vendor Invoices', route: '/dashboard/accounts/vendors/invoices' }] },
      { id: 'reports',   label: 'Reports',    desc: 'P&L, balance sheet and GST reports',    items: [{ label: 'Profit & Loss Report' },{ label: 'Balance Sheet' },{ label: 'Cash Flow Report' },{ label: 'GST Reports' }] },
    ],
  },
  stock: {
    label: 'Stock Management',
    subtitle: 'Inventory, warehouse and production control',
    sections: [
      { id: 'inventory', label: 'Inventory', desc: 'Stock levels, adjustments and transfers', route: '/dashboard/stock/inventory', items: [{ label: 'Stock Levels', route: '/dashboard/stock/inventory/stock-levels' },{ label: 'Item Catalog', route: '/dashboard/stock/inventory/item-catalog' },{ label: 'Stock Adjustment', route: '/dashboard/stock/inventory/stock-adjustment' },{ label: 'Stock Transfer', route: '/dashboard/stock/inventory/stock-transfer' }] },
      { id: 'items',     label: 'Items',     desc: 'Item catalog and bill of materials',      items: [{ label: 'Item List', route: '/dashboard/stock/items/item-list' },{ label: 'Add New Item', route: '/dashboard/stock/items/add-new-item' },{ label: 'Item Categories', route: '/dashboard/stock/items/item-categories' },{ label: 'Bill of Materials (BOM)', route: '/dashboard/stock/items/bill-of-materials' }] },
      { id: 'warehouse', label: 'Warehouse', desc: 'Warehouse locations and mapping',         items: [{ label: 'Warehouse List', route: '/dashboard/stock/warehouse/warehouse-list' },{ label: 'Add New Warehouse', route: '/dashboard/stock/warehouse/add-warehouse' },{ label: 'Location Mapping', route: '/dashboard/stock/warehouse/location-mapping' }] },
      { id: 'production',label: 'Production',desc: 'Work orders and production scheduling',   items: [{ label: 'Production Planning', route: '/dashboard/stock/production/production-planning' },{ label: 'Work Orders', route: '/dashboard/stock/production/work-orders' },{ label: 'Production Scheduling', route: '/dashboard/stock/production/production-scheduling' }] },
      { id: 'reports',   label: 'Reports',   desc: 'Stock and inventory analytics',   route: '/dashboard/stock/reports',    items: [{ label: 'Stock Report', route: '/dashboard/stock/reports/stock-report' },{ label: 'Inventory Report', route: '/dashboard/stock/reports/inventory-report' },{ label: 'Stock Movement Report', route: '/dashboard/stock/reports/stock-movement-report' },{ label: 'Production Report', route: '/dashboard/stock/reports/production-report' }] },
      { id: 'settings',  label: 'Settings',  desc: 'UOM, barcodes and inventory config',  route: '/dashboard/stock/settings',   items: [{ label: 'UOM Management', route: '/dashboard/stock/settings/uom' },{ label: 'Inventory Settings', route: '/dashboard/stock/settings/inventory-settings' },{ label: 'Barcode Settings' }] },
    ],
  },
  inventorymgmt: {
    label: 'Inventory Management',
    subtitle: 'Advanced inventory, MRP and warehouse ops',
    sections: [
      { id: 'items',     label: 'Items',     desc: 'Item list, categories and BOM',       items: [{ label: 'Item List', route: '/dashboard/stock/items/item-list' },{ label: 'Add New Item', route: '/dashboard/stock/items/add-new-item' },{ label: 'Item Categories', route: '/dashboard/stock/items/item-categories' },{ label: 'Bill of Materials (BOM)', route: '/dashboard/stock/items/bill-of-materials' }] },
      { id: 'stock',     label: 'Stock',     desc: 'Stock levels, adjustments and alerts', items: [{ label: 'Stock Levels' },{ label: 'Stock Adjustment' },{ label: 'Stock Transfer' },{ label: 'Stock Alerts' }] },
      { id: 'warehouse', label: 'Warehouse', desc: 'Warehouses, mapping and counts',       items: [{ label: 'Warehouse List', route: '/dashboard/stock/warehouse/warehouse-list' },{ label: 'Add New Warehouse', route: '/dashboard/stock/warehouse/add-warehouse' },{ label: 'Location Mapping', route: '/dashboard/stock/warehouse/location-mapping' },{ label: 'Inventory Counts' }] },
      { id: 'production',label: 'Production',desc: 'MRP, work orders and scheduling',      items: [{ label: 'Production Planning', route: '/dashboard/stock/production/production-planning' },{ label: 'Work Orders', route: '/dashboard/stock/production/work-orders' },{ label: 'Production Scheduling', route: '/dashboard/stock/production/production-scheduling' },{ label: 'Material Requirements Planning (MRP)' }] },
      { id: 'reports',   label: 'Reports',   desc: 'Valuation, accuracy and movement',     items: [{ label: 'Inventory Valuation Report' },{ label: 'Stock Movement Report' },{ label: 'Inventory Accuracy Report' },{ label: 'Slow-Moving Items Report' }] },
    ],
  },
};

// ── Module Overview Cards ─────────────────────────────────────────────────────
const ModuleOverview = ({ mod, basePath, moduleKey }) => {
  const navigate = useNavigate();
  const meta = MODULE_META[moduleKey] || MODULE_META.vendor;

  return (
    <div>
      {/* Hero header */}
      <div className={`relative rounded-3xl bg-gradient-to-r ${meta.gradient} p-6 mb-6 overflow-hidden shadow-lg`}>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -top-8 -right-8 w-40 h-40 rounded-full bg-white" />
          <div className="absolute -bottom-12 -left-6 w-56 h-56 rounded-full bg-white" />
        </div>
        <div className="relative">
          <p className="text-white/70 text-xs font-semibold uppercase tracking-widest mb-1">Module</p>
          <h2 className="text-2xl font-extrabold text-white mb-1">{mod.label}</h2>
          <p className="text-white/75 text-sm">{mod.subtitle}</p>
          <div className="flex items-center gap-2 mt-4">
            <span className="bg-white/20 text-white text-xs font-semibold px-3 py-1 rounded-full border border-white/30">
              {mod.sections.length} sections
            </span>
            <span className="bg-white/20 text-white text-xs font-semibold px-3 py-1 rounded-full border border-white/30">
              {mod.sections.reduce((a, s) => a + s.items.length, 0)} features
            </span>
          </div>
        </div>
      </div>

      {/* Section cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {mod.sections.map((sec, idx) => {
          const Icon = SECTION_ICONS[sec.id] || Package;
          const pal = CARD_PALETTES[idx % CARD_PALETTES.length];
          return (
            <button
              key={sec.id}
              onClick={() => navigate(sec.route || `${basePath}/${sec.id}`)}
              className="relative flex flex-col bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-250 group text-left overflow-hidden"
            >
              {/* Top gradient accent line */}
              <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ background: `linear-gradient(90deg, ${pal.icon}, ${pal.icon}88)` }} />

              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm transition-all duration-200 group-hover:scale-110"
                  style={{ background: pal.bg }}>
                  <Icon size={22} style={{ color: pal.icon }} />
                </div>
                <div className="w-7 h-7 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-gray-100 transition-colors">
                  <ArrowRight size={13} className="text-gray-400 group-hover:text-gray-600 transition-colors" />
                </div>
              </div>

              <h3 className="font-bold text-[#1E3448] text-base mb-1 group-hover:text-[#4C708E] transition-colors">{sec.label}</h3>
              <p className="text-xs text-gray-400 mb-4 leading-relaxed">{sec.desc}</p>

              <div className="mt-auto flex items-center gap-1.5">
                {sec.items.slice(0, 3).map((item, i) => (
                  <span key={i} className="text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ background: pal.bg, color: pal.icon }}>
                    {item.label.split(' ')[0]}
                  </span>
                ))}
                {sec.items.length > 3 && (
                  <span className="text-xs text-gray-400">+{sec.items.length - 3}</span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

// ── Sub-item list view ────────────────────────────────────────────────────────
const SectionItems = ({ section, mod, basePath, moduleKey }) => {
  const navigate = useNavigate();
  const meta = MODULE_META[moduleKey] || MODULE_META.vendor;
  const Icon = SECTION_ICONS[section.id] || Package;

  return (
    <div>
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-[#6B92AB] mb-4 font-medium">
        <button onClick={() => navigate(basePath)} className="hover:text-[#4C708E] transition-colors">{mod.label}</button>
        <ChevronRight size={12} className="text-gray-300" />
        <span className="text-[#2D4A5E] font-semibold">{section.label}</span>
      </div>

      {/* Section header */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate(basePath)}
          className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center text-[#4C708E] hover:bg-[#EBF4FB] transition-colors shadow-sm"
        >
          <ArrowLeft size={16} />
        </button>
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm"
          style={{ background: meta.light }}>
          <Icon size={22} style={{ color: meta.accent }} />
        </div>
        <div>
          <h2 className="text-xl font-bold text-[#1E3448]">{section.label}</h2>
          <p className="text-sm text-[#8BAFC7]">{section.desc}</p>
        </div>
      </div>

      {/* Items as list */}
      <div className="rounded-2xl border border-[#E8F1F8] overflow-hidden shadow-sm divide-y divide-[#E8F1F8] bg-white">
        {section.items.map((item, idx) => (
          <button
            key={idx}
            onClick={() => item.route && navigate(item.route)}
            className="flex items-center gap-4 w-full text-left px-5 py-4 hover:bg-[#F8FBFD] transition-all duration-150 group"
          >
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors"
              style={{ background: meta.light }}>
              <span className="text-xs font-bold transition-colors" style={{ color: meta.accent }}>{idx + 1}</span>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-[#1E3448] text-sm group-hover:text-[#4C708E] transition-colors">{item.label}</p>
            </div>
            <ChevronRight size={15} className="text-gray-300 group-hover:text-[#4C708E] flex-shrink-0 transition-colors" />
          </button>
        ))}
      </div>
    </div>
  );
};

// ── Main component ────────────────────────────────────────────────────────────
const SubItemsPage = ({ moduleKey }) => {
  const { sectionId: paramSectionId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const mod = allModules[moduleKey];
  if (!mod) return <div className="p-6 text-red-500">Module not found</div>;

  const basePath = `/dashboard/${moduleKey}`;

  // If :sectionId param is not set, try reading the last URL segment
  // e.g. /dashboard/purchase/purchase-orders → sectionId = 'purchase-orders'
  const lastSegment = location.pathname.replace(basePath, '').replace(/^\//, '').split('/')[0];
  const sectionId = paramSectionId || (lastSegment && lastSegment !== moduleKey ? lastSegment : undefined);
  const section = mod.sections.find((s) => s.id === sectionId);

  if (!section) {
    return <ModuleOverview mod={mod} basePath={basePath} moduleKey={moduleKey} />;
  }

  return <SectionItems section={section} mod={mod} basePath={basePath} moduleKey={moduleKey} />;
};

export default SubItemsPage;
