import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Settings, Save, CheckCircle, XCircle,
  ToggleLeft, ToggleRight, Package, AlertTriangle,
} from 'lucide-react';

const LS_KEY = 'srivaari_inventory_settings';

const VALUATION_METHODS = ['FIFO', 'LIFO', 'AVG'];

const defaultSettings = {
  enableBatchTracking:  false,
  enableExpiryTracking: false,
  stockValuationMethod: 'FIFO',
  defaultReorderLevel:  0,
  allowNegativeStock:   false,
};

const ToggleField = ({ label, desc, value, onChange }) => (
  <div className="flex items-center justify-between p-4 rounded-2xl border border-[#E8F1F8] bg-white hover:border-[#4C708E]/30 transition-colors">
    <div>
      <p className="text-sm font-semibold text-[#1E3448]">{label}</p>
      {desc && <p className="text-xs text-[#8BAFC7] mt-0.5">{desc}</p>}
    </div>
    <button
      onClick={() => onChange(!value)}
      className="flex-shrink-0 ml-4 transition-colors"
    >
      {value
        ? <ToggleRight size={32} className="text-[#4C708E]" />
        : <ToggleLeft  size={32} className="text-[#C5D8E8]" />}
    </button>
  </div>
);

const Toast = ({ toast }) => {
  if (!toast) return null;
  const isErr = toast.type === 'error';
  return (
    <div className={`fixed bottom-6 right-6 z-[999] flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-xl text-sm font-semibold border ${isErr ? 'bg-red-50 text-red-700 border-red-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
      <span className={`w-2 h-2 rounded-full ${isErr ? 'bg-red-400' : 'bg-emerald-400'}`} />
      {toast.msg}
    </div>
  );
};

export default function InventorySettingsPage() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState(defaultSettings);
  const [saving, setSaving]     = useState(false);
  const [toast, setToast]       = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => {
    try {
      const d = localStorage.getItem(LS_KEY);
      if (d) setSettings({ ...defaultSettings, ...JSON.parse(d) });
    } catch {}
  }, []);

  const fs = (k, v) => setSettings(p => ({ ...p, [k]: v }));

  const handleSave = () => {
    setSaving(true);
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(settings));
      showToast('Inventory settings saved successfully.');
    } catch {
      showToast('Failed to save settings.', 'error');
    }
    setSaving(false);
  };

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      <Toast toast={toast} />

      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4C708E] to-[#8BAFC7] flex items-center justify-center">
            <Settings size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Inventory Settings</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Configure batch tracking, valuation and stock rules</p>
          </div>
        </div>
      </div>

      <div className="max-w-2xl space-y-5">

        {/* Tracking Toggles */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
          <div className="px-6 py-4 border-b border-[#E8F1F8] bg-gradient-to-r from-[#EBF4FB] to-white">
            <h2 className="text-sm font-bold text-[#2D4A5E] flex items-center gap-2">
              <Package size={14} className="text-[#4C708E]" /> Tracking Options
            </h2>
          </div>
          <div className="p-6 space-y-3">
            <ToggleField
              label="Enable Batch Tracking"
              desc="Track items by batch/lot numbers for traceability"
              value={settings.enableBatchTracking}
              onChange={v => fs('enableBatchTracking', v)}
            />
            <ToggleField
              label="Enable Expiry Tracking"
              desc="Monitor expiry dates and alert before items expire"
              value={settings.enableExpiryTracking}
              onChange={v => fs('enableExpiryTracking', v)}
            />
          </div>
        </div>

        {/* Valuation Method */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
          <div className="px-6 py-4 border-b border-[#E8F1F8] bg-gradient-to-r from-[#EBF4FB] to-white">
            <h2 className="text-sm font-bold text-[#2D4A5E]">Stock Valuation Method</h2>
          </div>
          <div className="p-6">
            <p className="text-xs text-[#8BAFC7] mb-4">Choose how stock value is calculated for reporting and accounting.</p>
            <div className="grid grid-cols-3 gap-3">
              {VALUATION_METHODS.map(method => (
                <button
                  key={method}
                  onClick={() => fs('stockValuationMethod', method)}
                  className={`py-4 rounded-2xl border-2 text-sm font-bold transition-all ${
                    settings.stockValuationMethod === method
                      ? 'border-[#4C708E] bg-[#EBF4FB] text-[#1E3448]'
                      : 'border-[#E8F1F8] bg-white text-[#8BAFC7] hover:border-[#4C708E]/30'
                  }`}
                >
                  <span className="block text-lg mb-1">{method === 'AVG' ? '⌀' : method === 'FIFO' ? '→' : '←'}</span>
                  {method === 'AVG' ? 'Average' : method}
                  <span className="block text-xs font-normal mt-0.5 text-[#8BAFC7]">
                    {method === 'FIFO' ? 'First In First Out' : method === 'LIFO' ? 'Last In First Out' : 'Weighted Average'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Reorder Level */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
          <div className="px-6 py-4 border-b border-[#E8F1F8] bg-gradient-to-r from-[#EBF4FB] to-white">
            <h2 className="text-sm font-bold text-[#2D4A5E] flex items-center gap-2">
              <AlertTriangle size={14} className="text-[#d97706]" /> Reorder Configuration
            </h2>
          </div>
          <div className="p-6">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Default Reorder Level</label>
              <p className="text-xs text-[#8BAFC7] mb-2">Alert will trigger when stock falls below this quantity.</p>
              <input
                type="number"
                min="0"
                value={settings.defaultReorderLevel}
                onChange={e => fs('defaultReorderLevel', parseInt(e.target.value) || 0)}
                className="w-full max-w-xs rounded-xl border border-[#D6E6F2] bg-white px-4 py-3 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all"
              />
            </div>
          </div>
        </div>

        {/* Negative Stock */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
          <div className="px-6 py-4 border-b border-[#E8F1F8] bg-gradient-to-r from-[#EBF4FB] to-white">
            <h2 className="text-sm font-bold text-[#2D4A5E]">Stock Rules</h2>
          </div>
          <div className="p-6">
            <ToggleField
              label="Allow Negative Stock"
              desc="Allow stock levels to go below zero (use with caution)"
              value={settings.allowNegativeStock}
              onChange={v => fs('allowNegativeStock', v)}
            />
            {settings.allowNegativeStock && (
              <div className="mt-3 flex items-start gap-2 px-4 py-3 rounded-xl bg-amber-50 border border-amber-200">
                <AlertTriangle size={14} className="text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700">Warning: Allowing negative stock may lead to inaccurate inventory reports. Enable only if your workflow requires it.</p>
              </div>
            )}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end pt-2">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-8 py-3 rounded-xl bg-[#4C708E] text-white text-sm font-semibold hover:bg-[#2D4A5E] transition-colors shadow-md disabled:opacity-60"
          >
            {saving
              ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : <Save size={15} />}
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
}
