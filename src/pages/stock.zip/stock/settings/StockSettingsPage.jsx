import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Settings, Ruler, SlidersHorizontal, QrCode } from 'lucide-react';

const SETTINGS_SECTIONS = [
  {
    label: 'UOM Management',
    desc:  'Create and manage Units of Measurement (Kg, Liter, Piece…)',
    icon:  Ruler,
    route: '/dashboard/stock/settings/uom',
    color: '#4C708E',
    bg:    '#EBF4FB',
  },
  {
    label: 'Inventory Settings',
    desc:  'Batch tracking, expiry, valuation method and reorder rules',
    icon:  SlidersHorizontal,
    route: '/dashboard/stock/settings/inventory-settings',
    color: '#059669',
    bg:    '#d1fae5',
  },
  {
    label: 'Barcode Settings',
    desc:  'Barcode format, prefix and print configuration (coming soon)',
    icon:  QrCode,
    route: null,
    color: '#d97706',
    bg:    '#fef3c7',
    disabled: true,
  },
];

export default function StockSettingsPage() {
  const navigate = useNavigate();

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm"
        >
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4C708E] to-[#8BAFC7] flex items-center justify-center">
            <Settings size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">Settings</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">UOM, barcodes and inventory configuration</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {SETTINGS_SECTIONS.map((sec, idx) => {
          const Icon = sec.icon;
          return (
            <button
              key={idx}
              onClick={() => !sec.disabled && sec.route && navigate(sec.route)}
              disabled={sec.disabled}
              className={`relative flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm border border-[#E8F1F8] text-left overflow-hidden transition-all duration-200
                ${sec.disabled ? 'opacity-60 cursor-not-allowed' : 'hover:shadow-xl hover:-translate-y-1 group cursor-pointer'}`}
            >
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all duration-200 ${!sec.disabled ? 'group-hover:scale-110' : ''}`}
                style={{ background: sec.bg }}
              >
                <Icon size={24} style={{ color: sec.color }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className={`font-bold text-[#1E3448] text-base transition-colors ${!sec.disabled ? 'group-hover:text-[#4C708E]' : ''}`}>{sec.label}</p>
                  {sec.disabled && (
                    <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-400">Coming Soon</span>
                  )}
                </div>
                <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{sec.desc}</p>
              </div>
              <span className="text-2xl font-black opacity-10 absolute right-4 top-1/2 -translate-y-1/2" style={{ color: sec.color }}>
                {idx + 1}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
