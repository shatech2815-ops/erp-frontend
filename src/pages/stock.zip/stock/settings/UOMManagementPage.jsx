import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Ruler, Plus, Trash2, Save, X,
  CheckCircle, AlertCircle, Edit2, Search,
} from 'lucide-react';

const LS_KEY = 'srivaari_uom_list';

const emptyForm = { name: '', description: '', active: true };

const Toast = ({ toast }) => {
  if (!toast) return null;
  const isErr = toast.type === 'error';
  return (
    <div className={`fixed bottom-6 right-6 z-[999] flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-xl text-sm font-semibold border ${isErr ? 'bg-red-50 text-red-700 border-red-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
      <span className={`w-2 h-2 rounded-full ${isErr ? 'bg-red-400' : 'bg-emerald-400'}`} />
      {toast.msg}
    </div>
  );
};

export default function UOMManagementPage() {
  const navigate = useNavigate();
  const [uoms, setUoms]         = useState([]);
  const [form, setForm]         = useState(emptyForm);
  const [editId, setEditId]     = useState(null);
  const [search, setSearch]     = useState('');
  const [saving, setSaving]     = useState(false);
  const [toast, setToast]       = useState(null);
  const [deleteId, setDeleteId] = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => {
    try { const d = localStorage.getItem(LS_KEY); if (d) setUoms(JSON.parse(d)); } catch {}
  }, []);

  const persist = (data) => {
    try { localStorage.setItem(LS_KEY, JSON.stringify(data)); } catch {}
  };

  const handleSave = () => {
    if (!form.name.trim()) { showToast('UOM name is required.', 'error'); return; }
    setSaving(true);
    let updated;
    if (editId !== null) {
      updated = uoms.map(u => u.id === editId ? { ...u, ...form } : u);
      showToast('UOM updated.');
      setEditId(null);
    } else {
      updated = [...uoms, { ...form, id: Date.now() }];
      showToast('UOM created.');
    }
    setUoms(updated);
    persist(updated);
    setForm(emptyForm);
    setSaving(false);
  };

  const handleEdit = (u) => {
    setForm({ name: u.name, description: u.description || '', active: u.active });
    setEditId(u.id);
  };

  const handleDelete = (id) => {
    const updated = uoms.filter(u => u.id !== id);
    setUoms(updated);
    persist(updated);
    setDeleteId(null);
    showToast('UOM deleted.');
  };

  const filtered = uoms.filter(u =>
    !search || u.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 min-h-screen" style={{ background: '#F0F6FB' }}>
      <Toast toast={toast} />

      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-7">
            <div className="w-14 h-14 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-4">
              <Trash2 size={24} className="text-red-500" />
            </div>
            <p className="text-center text-[#1E3448] font-semibold mb-1">Delete UOM?</p>
            <p className="text-center text-xs text-[#8BAFC7] mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="flex-1 py-2.5 rounded-xl border border-[#D6E6F2] text-[#4C708E] text-sm font-semibold hover:bg-[#EBF4FB] transition-colors">Cancel</button>
              <button onClick={() => handleDelete(deleteId)} className="flex-1 py-2.5 rounded-xl bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition-colors">Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-xl border border-[#D6E6F2] bg-white flex items-center justify-center hover:bg-[#EBF4FB] transition-colors shadow-sm">
          <ArrowLeft size={16} className="text-[#4C708E]" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4C708E] to-[#8BAFC7] flex items-center justify-center">
            <Ruler size={15} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#1E3448]">UOM Management</h1>
            <p className="text-xs text-[#8BAFC7] mt-0.5">Units of Measurement — Kilogram, Liter, Piece…</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <span className="px-3 py-1.5 rounded-xl bg-white border border-[#D6E6F2] text-xs text-[#4C708E] font-semibold shadow-sm">
            {uoms.length} UOMs
          </span>
        </div>
      </div>

      {/* Form */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] mb-6 overflow-hidden">
        <div className="flex items-center gap-2 px-6 py-4 bg-gradient-to-r from-[#EBF4FB] to-white border-b border-[#D6E6F2]">
          <Plus size={15} className="text-[#4C708E]" />
          <h2 className="text-sm font-bold text-[#2D4A5E]">{editId !== null ? 'Edit UOM' : 'Create UOM'}</h2>
          {editId !== null && (
            <button onClick={() => { setForm(emptyForm); setEditId(null); }} className="ml-auto flex items-center gap-1 text-xs text-[#8BAFC7] hover:text-red-500">
              <X size={13} /> Cancel
            </button>
          )}
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">UOM Name <span className="text-red-400">*</span></label>
              <input
                type="text" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                placeholder="e.g. Kilogram, Liter, Piece"
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Description</label>
              <input
                type="text" value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                placeholder="Optional description"
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 focus:border-[#4C708E] transition-all"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-[#4C708E] uppercase tracking-wide">Status</label>
              <select
                value={form.active ? 'true' : 'false'}
                onChange={e => setForm(p => ({ ...p, active: e.target.value === 'true' }))}
                className="w-full rounded-xl border border-[#D6E6F2] bg-white px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30 appearance-none"
              >
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end">
            <button onClick={handleSave} disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#4C708E] text-white text-sm font-semibold hover:bg-[#2D4A5E] transition-colors shadow-md disabled:opacity-60">
              {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={15} />}
              {editId !== null ? 'Update UOM' : 'Save UOM'}
            </button>
          </div>
        </div>
      </div>

      {/* List */}
      <div className="bg-white rounded-2xl shadow-sm border border-[#E8F1F8] overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 px-6 py-4 border-b border-[#E8F1F8]">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8BAFC7]" />
            <input placeholder="Search UOM…" value={search} onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#D6E6F2] text-sm focus:outline-none focus:ring-2 focus:ring-[#4C708E]/30" />
          </div>
          <span className="text-xs text-[#8BAFC7] ml-auto">{filtered.length} units</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gradient-to-r from-[#4C708E] to-[#6B92AB] text-white text-xs uppercase tracking-wide">
                {['UOM Name', 'Description', 'Status', 'Actions'].map(h => (
                  <th key={h} className="px-6 py-3 text-left font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={4} className="text-center py-14 text-[#8BAFC7] text-sm">No UOMs found. Create one above.</td></tr>
              ) : filtered.map((u, idx) => (
                <tr key={u.id} className={`border-b border-[#F0F6FB] hover:bg-[#F7FBFE] transition-colors ${idx % 2 === 0 ? '' : 'bg-[#FAFCFE]'}`}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-[#EBF4FB] flex items-center justify-center flex-shrink-0">
                        <Ruler size={15} className="text-[#4C708E]" />
                      </div>
                      <span className="text-sm font-semibold text-[#1E3448]">{u.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-xs text-[#6B7280]">{u.description || '—'}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${u.active ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-500'}`}>
                      {u.active ? <CheckCircle size={10} /> : <AlertCircle size={10} />}
                      {u.active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button onClick={() => handleEdit(u)} className="w-8 h-8 rounded-xl bg-[#EBF4FB] hover:bg-[#4C708E] hover:text-white text-[#4C708E] flex items-center justify-center transition-colors"><Edit2 size={13} /></button>
                      <button onClick={() => setDeleteId(u.id)} className="w-8 h-8 rounded-xl bg-[#fee2e2] hover:bg-red-500 hover:text-white text-red-500 flex items-center justify-center transition-colors"><Trash2 size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
